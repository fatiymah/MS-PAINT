//
//  paint.h
//  MS paint
//
//  Created by Akbar Khan on 25/06/2021.
//  Copyright © 2021 Akbar Khan. All rights reserved.
//

#ifndef paint_h
#define paint_h
#include<iostream>
using namespace std;

class Shape {
    //point, color, numberOfPoints
    //        public:
//draw()=0, contains(points)=0;

};
class openShape : public Shape {
    //style
    //        public:
    //changeColour()=0;

};
class polygon : public Shape {

    //fillColour
    //        public:
    //draw(),contains(points),fill(int colour);
};
class circle : public Shape {
    //radius
    //public:
    //draw(); contains(points);fill(int colour);
};
class line : public openShape {
    //public:
    //draw(),contains(points), changeColour();
};
class curve :public openShape {
    //public:
    //draw(),contains(points), changeColour();
};
class Rectangle : public polygon {
    //public:
    //contains(points); fill(int color)
};
class Text : public Shape {
    //changeColour(),draw(), contains(points);
};

#endif /* paint_h */
