#include <SFML/Graphics.hpp>



#include<iostream>

#include<fstream>

#include<cmath>



#include<vector>



#include<iostream>



#include <cstdlib>



#include"ResourcePath.hpp"

using namespace sf;



using namespace std;

sf::RenderWindow window(sf::VideoMode(2000, 1400), "SFML window", sf::Style::Close);

class line;
using namespace std;

class Shapes;
class Shapes {
    int** points;
    int numberOfPoints;
public:
    
    
    
    string _color;
    
    
    
    void set_no_of_points(int n) {
        
        
        
        numberOfPoints = n;
        
        
        
    }
    
    
    
    int get_no_of_points() {
        
        
        
        return numberOfPoints;
        
        
        
    }
    
    
    
    void set_points(int** p) {
        
        
        
        points = new int* [numberOfPoints];
        
        
        
        
        
        
        
        for (int i = 0; i < numberOfPoints; i++) {
            
            
            
            points[i] = new int[2];
            
            
            
        }
        
        
        
        points = p;
        
        
        
    }
    
    
    
    int** get_points() {
        
        
        
        return points;
        
        
        
    }
    
    
    
    Shapes() {
        
        
        
        numberOfPoints = 0;
        
        
        
        _color = "default";
        
        
        
        points = nullptr;
        
        
        
    }
    
    
    
    Shapes(Shapes& obj) {
        
        
        
        numberOfPoints = obj.numberOfPoints;
        
        
        
        _color = obj._color;
        
        
        
        points = new int* [numberOfPoints];
        
        
        
        
        
        
        
        for (int i = 0; i < numberOfPoints; i++)
            
            
            
            
            
            
            
            points[i] = new int[2];
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        for (int i = 0; i < numberOfPoints; i++) {
            
            
            
            
            
            
            
            for (int j = 0; j < 2; j++)
                
                
                
                
                
                
                
                points[i][j] = obj.points[i][j];
            
            
            
        }
        
        
        
        
        
        
        
    }
    
    
    
    
    
    
    
    Shapes(int** p, string c, int n) {
        
        
        
        
        
        
        
        numberOfPoints = n;
        
        
        
        
        
        
        
        _color = c;
        
        
        
        points = new int* [numberOfPoints];
        
        
        
        
        
        
        
        for (int i = 0; i < numberOfPoints; i++)
            
   
            points[i] = new int[2];
        
        for (int i = 0; i < numberOfPoints; i++) {
            
            
            
            
            
            
            
            for (int j = 0; j < 2; j++)
                
                points[i][j] = p[i][j];
            
            
            
        }
     
    }
   
    virtual void draw() = 0;
   
    
    virtual int** contains(int** points) = 0;
    
    ~Shapes() {
      
        
      //  _color = " ";
      
    }
    
};



class openShape : virtual public Shapes {
    
    string style;
  
public:
    
    
    
    openShape() :Shapes() {
        
        
        
        style = "";
        
        
        
    }
    
    
    
    
    
    
    
    openShape(int** p, string c, int n, string s) :Shapes(p, c, n) {
        
        style = s;
        
    }
    
    openShape(openShape& obj) :Shapes(obj) {
       
        style = obj.style;
        
    }
    
    int** contains(int** point) {
       
        set_points(point);
        
        return get_points();
        
    }
    
    
    
    virtual void changeColour() = 0;
    
    
    
    virtual void draw() = 0;
    
    
    
};



class polygon : public virtual Shapes {
    
    
    
    string fillColour;
    
    
    
    
    
    
    
public:
    
    
    
    polygon() :Shapes() {
        
        
        
        
        
        
        
        fillColour = "";
        
        
        
    }
    
    
    
    
    
    
    
    polygon(int** p, string c, int n, string s) :Shapes(p, c, n) {
        
        
        
        
        
        
        
        fillColour = s;
        
        
        
    }
    
    
    
    polygon(polygon& obj) :Shapes(obj) {
        
        
        
        fillColour = obj.fillColour;
        
        
        
        
        
        
        
    }
    
    
    
    virtual void draw()
    
    
    
    {
        
        
        
        int** point = get_points();
        
        
        
        sf::VertexArray line81(sf::LineStrip, 2);
        
        
        
        
        
        
        
        line81[0].position = sf::Vector2f(point[0][0], point[0][1]);
        
        
        
        line81[1].position = sf::Vector2f(point[1][0], point[1][1]);
        
        
        
        
        
        
        
        line81[0].color = sf::Color::Black;
        
        
        
        
        
        
        
        line81[1].color = sf::Color::Black;
        
        
        
        
        
        
        
        window.draw(line81);
        
        
        
        
        
        
        
    }
    
    
    
    int** contains(int** point) {
        
        
        
        
        
        
        
        set_points(point);
        
        
        
        return get_points();
        
        
        
    }
    
    
    
    void fill(int colour) {
        
        
        
        
        
        
        
    }
    
    
    
    
    
    
    
};



class circle : virtual public Shapes {
    
    
    
    int radius;
    
    
    
public:
    
    
    
    circle() :Shapes() {
        
        
        
        
        
        
        
        radius = 0;
        
        
        
    }
    
    
    
    circle(int** p, string c, int n, int r) :Shapes() {
        
        
        
        
        
        
        
        radius = r;
        
        
        
    }
    
    
    void draw() {
        
        
        
        sf::CircleShape shape;
        
        
        int** point = get_points();
        
        
        radius = sqrt(pow(point[0][0] - point[1][0], 2) +
                      
                      pow(point[0][1] - point[1][1], 2) * 1.0);
        
        // std::cout << "sub" << radius << endl;
        
        
        
        /* if(_color=="Red"){
         
         shape.setRadius(radius);
         
         
         
         shape.setOutlineThickness(1);
         
         
         
         shape.setOutlineColor(sf::Color::Black);
         
         
         
         shape.setFillColor(sf::Color::Red);
         
         
         
         shape.setPosition(point[0][0], point[0][1]);
         
         
         
         shape.setOrigin(radius, radius);
         
         
         
         window.draw(shape);
         
         
         
         
         
         
         
         
         
         
         
         }*/
        
        
        
        //  else
        
        
        
        shape.setRadius(radius);
        
        
        if(_color=="White")
        {
            cout<<"erase circle "<<endl;
            shape.setOutlineThickness(5);
            
            
            
            shape.setOutlineColor(sf::Color::White);
            
            
            
            shape.setFillColor(sf::Color::White);
            
            
            
            shape.setPosition(point[0][0], point[0][1]);
            
            
            
            shape.setOrigin(radius, radius);
        }
        else{
            shape.setRadius(radius);
            
            
            
            shape.setOutlineThickness(1);
            
            
            
            shape.setOutlineColor(sf::Color(0, 0, 0));
            
            
            
            shape.setFillColor(sf::Color::White);
            
            
            
            shape.setPosition(point[0][0], point[0][1]);
            
            
            
            shape.setOrigin(radius, radius);
        }
        
        
        window.draw(shape);
        
        
        
        
        
        
        
    }
    
    
    
    int** contains(int** point) {
        
        
        
        set_points(point);
        
        
        
        
        
        
        
        return get_points();
        
        
        
    }
    
    
    void fill(int colour) {
        
        cout << "----------------FILL COLOUR----------------" << endl;
        
        cout << "=======colour " << _color << " ==========" << endl;
        
        int** points = get_points();
        
        sf::VertexArray shade;
        
        if (this->_color == "Red") {
            radius = sqrt(pow(points[0][0] - points[1][0], 2) + pow(points[0][1] - points[1][1], 2 * 1.0));
            
            // _radius= 100 ;
            
            sf::Vertex pixel;
            
            // sf::VertexArray shade ;
            
            pixel.color = sf::Color::Red;
            
            cout << "-----------RED CIRCLE----------" << endl;
            
            for (int i = 0; i < 2000; i++)
            {
                for (int j = 0; j < 1400; j++)
                {
                    pixel.position = sf::Vector2f(i, j);
                    
                    if ((radius * radius) > ((i - points[0][0]) * (i - points[0][0])) + ((j - points[0][1]) * (j - points[0][1])))
                    {
                        shade.append(pixel);
                        
                    }
                    
                }
                
            }
            
            
            
        }
        
        else if (_color == "Blue") {
            
            
            
            radius = sqrt(pow(points[0][0] - points[1][0], 2) + pow(points[0][1] - points[1][1], 2 * 1.0));
            
            
            
            // _radius= 100 ;
            
            
            
            sf::Vertex pixel;
            
            
            
            // sf::VertexArray shade ;
            
            
            
            pixel.color = sf::Color::Blue;
            
            
            
            for (int i = 0; i < 2000; i++)
                
                
                
            {
                
                
                
                for (int j = 0; j < 1400; j++)
                    
                    
                    
                {
                    
                    
                    
                    pixel.position = sf::Vector2f(i, j);
                    
                    
                    
                    if ((radius * radius) > ((i - points[0][0]) * (i - points[0][0])) + ((j - points[0][1]) * (j - points[0][1])))
                        
                        
                        
                    {
                        
                        
                        
                        shade.append(pixel);
                        
                        
                        
                    }
                    
                    
                    
                    
                    
                    
                    
                }
                
                
                
            }
            
            
            
        }
        
        else if (_color == "White") {
            
            
            cout<<"fill white "<<endl;
            radius = sqrt(pow(points[0][0] - points[1][0], 2) + pow(points[0][1] - points[1][1], 2 * 1.0));
            
            
            
            // _radius= 100 ;
            
            
            
            sf::Vertex pixel;
            
            
            
            // sf::VertexArray shade ;
            
            
            
            pixel.color = sf::Color::White;
            
            
            
            for (int i = 0; i < 2000; i++)
                
                
                
            {
                
                
                
                for (int j = 0; j < 1400; j++)
                    
                    
                    
                {
                    
                    
                    
                    pixel.position = sf::Vector2f(i, j);
                    
                    
                    
                    if ((radius * radius) > ((i - points[0][0]) * (i - points[0][0])) + ((j - points[0][1]) * (j - points[0][1])))
                        
                        
                        
                    {
                        
                        
                        
                        shade.append(pixel);
                        
                        
                        
                    }
                    
                    
                    
                    
                    
                    
                    
                }
                
                
                
            }
            
            
            
        }
        
        else if (_color == "Magenta") {
            
            
            
            radius = sqrt(pow(points[0][0] - points[1][0], 2) + pow(points[0][1] - points[1][1], 2 * 1.0));
            
            
            
            // _radius= 100 ;
            
            
            
            sf::Vertex pixel;
            
            
            
            // sf::VertexArray shade ;
            
            
            
            pixel.color = sf::Color::Magenta;
            
            
            
            for (int i = 0; i < 2000; i++)
                
                
                
            {
                
                
                
                for (int j = 0; j < 1400; j++)
                    
                    
                    
                {
                    
                    
                    
                    pixel.position = sf::Vector2f(i, j);
                    
                    
                    
                    if ((radius * radius) > ((i - points[0][0]) * (i - points[0][0])) + ((j - points[0][1]) * (j - points[0][1])))
                        
                        
                        
                    {
                        
                        
                        
                        shade.append(pixel);
                        
                        
                        
                    }
                    
                    
                    
                    
                    
                    
                    
                }
                
                
                
            }
            
            
            
        }
        
        
        
        else if (_color == "Green") {
            
            
            
            radius = sqrt(pow(points[0][0] - points[1][0], 2) + pow(points[0][1] - points[1][1], 2 * 1.0));
            
            
            
            // _radius= 100 ;
            
            
            
            sf::Vertex pixel;
            
            
            
            // sf::VertexArray shade ;
            
            
            
            pixel.color = sf::Color::Green;
            
            
            
            for (int i = 0; i < 2000; i++)
                
                
                
            {
                
                
                
                for (int j = 0; j < 1400; j++)
                    
                    
                    
                {
                    
                    
                    
                    pixel.position = sf::Vector2f(i, j);
                    
                    
                    
                    if ((radius * radius) > ((i - points[0][0]) * (i - points[0][0])) + ((j - points[0][1]) * (j - points[0][1])))
                        
                        
                        
                    {
                        
                        
                        
                        shade.append(pixel);
                        
                        
                        
                    }
                    
                    
                    
                    
                    
                    
                    
                }
                
                
                
            }
            
            
            
        }
        
        
        
        else  if (_color == "Black") {
            
            
            
            radius = sqrt(pow(points[0][0] - points[1][0], 2) + pow(points[0][1] - points[1][1], 2 * 1.0));
            
            
            
            // _radius= 100 ;
            
            
            
            sf::Vertex pixel;
            
            
            
            // sf::VertexArray shade ;
            
            
            
            pixel.color = sf::Color::Black;
            
            
            
            for (int i = 0; i < 2000; i++)
                
                
                
            {
                
                
                
                for (int j = 0; j < 1400; j++)
                    
                    
                    
                {
                    
                    
                    
                    pixel.position = sf::Vector2f(i, j);
                    
                    
                    
                    if ((radius * radius) > ((i - points[0][0]) * (i - points[0][0])) + ((j - points[0][1]) * (j - points[0][1])))
                        
                        
                        
                    {
                        
                        
                        
                        shade.append(pixel);
                        
                        
                        
                    }
                    
                    
                    
                    
                    
                    
                    
                }
                
                
                
            }
            
            
            
        }
        
        
        
        else if (_color == "Grey") {
            
            
            
            radius = sqrt(pow(points[0][0] - points[1][0], 2) + pow(points[0][1] - points[1][1], 2 * 1.0));
            
            
            
            // _radius= 100 ;
            
            
            
            sf::Vertex pixel;
            
            
            
            // sf::VertexArray shade ;
            
            
            
            pixel.color = sf::Color(192, 192, 192);
            
            
            
            for (int i = 0; i < 2000; i++)
                
                
                
            {
                
                
                
                for (int j = 0; j < 1400; j++)
                    
                    
                    
                {
                    
                    
                    
                    pixel.position = sf::Vector2f(i, j);
                    
                    
                    
                    if ((radius * radius) > ((i - points[0][0]) * (i - points[0][0])) + ((j - points[0][1]) * (j - points[0][1])))
                        
                        
                        
                    {
                        
                        
                        
                        shade.append(pixel);
                        
                        
                        
                    }
                    
                    
                    
                    
                    
                    
                    
                }
                
                
                
            }
            
            
            
        }
        
        
        
        else  if (_color == "Yellow") {
            
            
            
            radius = sqrt(pow(points[0][0] - points[1][0], 2) + pow(points[0][1] - points[1][1], 2 * 1.0));
            
            
            
            // _radius= 100 ;
            
            
            
            sf::Vertex pixel;
            
            
            
            // sf::VertexArray shade ;
            
            
            
            pixel.color = sf::Color::Yellow;
            
            
            
            for (int i = 0; i < 2000; i++)
                
                
                
            {
                
                
                
                for (int j = 0; j < 1400; j++)
                    
                    
                    
                {
                    
                    
                    
                    pixel.position = sf::Vector2f(i, j);
                    
                    
                    
                    if ((radius * radius) > ((i - points[0][0]) * (i - points[0][0])) + ((j - points[0][1]) * (j - points[0][1])))
                        
                        
                        
                    {
                        
                        
                        
                        shade.append(pixel);
                        
                        
                        
                    }
                    
                    
                    
                    
                    
                    
                    
                }
                
                
                
            }
            
            
            
        }
        
        
        
        window.draw(shade);
        
        
        
    }
    
};



class line : public openShape {
    
    
    
    
    
    
    
public:
    
    
    
    line()
    
    
    
    {
        
        
        
        
        
        
        
    }
    
    
    
    virtual void draw()
    
    
    
    {
        
        
        
        
        
        
        
        int** point = get_points();
        
        
        
        sf::VertexArray line8(sf::LineStrip, 2);
        
        
        
        
        
        
        
        cout << "================" << this->_color << "=================" << endl;
        
        
        
        if (this->_color == "Red") {
            
            
            
            line8[0].position = sf::Vector2f(point[0][0], point[0][1]);
            
            
            
            line8[1].position = sf::Vector2f(point[1][0], point[1][1]);
            
            
            
            
            
            
            
            line8[0].color = sf::Color::Red;
            
            
            
            
            
            
            
            line8[1].color = sf::Color::Red;
            
            
            
        }
        
        
        
        else if (this->_color == "Yellow") {
            
            
            
            line8[0].position = sf::Vector2f(point[0][0], point[0][1]);
            
            
            
            line8[1].position = sf::Vector2f(point[1][0], point[1][1]);
            
            
            
            
            
            
            
            line8[0].color = sf::Color::Yellow;
            
            
            
            
            
            
            
            line8[1].color = sf::Color::Yellow;
            
            
            
        }
        
        
        
        else if (this->_color == "Blue") {
            
            
            
            line8[0].position = sf::Vector2f(point[0][0], point[0][1]);
            
            
            
            line8[1].position = sf::Vector2f(point[1][0], point[1][1]);
            
            
            
            
            
            
            
            line8[0].color = sf::Color::Blue;
            
            
            
            
            
            
            
            line8[1].color = sf::Color::Blue;
            
            
            
        }
        
        
        
        else if (this->_color == "Green") {
            
            
            
            line8[0].position = sf::Vector2f(point[0][0], point[0][1]);
            
            
            
            line8[1].position = sf::Vector2f(point[1][0], point[1][1]);
            
            
            
            
            
            
            
            line8[0].color = sf::Color::Green;
            
            
            
            
            
            
            
            line8[1].color = sf::Color::Green;
            
            
            
        }
        
        
        
        else if (this->_color == "Grey") {
            
            
            
            line8[0].position = sf::Vector2f(point[0][0], point[0][1]);
            
            
            
            line8[1].position = sf::Vector2f(point[1][0], point[1][1]);
            
            
            
            
            
            
            
            line8[0].color = sf::Color(192, 192, 192);
            
            
            
            
            
            
            
            line8[1].color = sf::Color(192, 192, 192);
            
            
            
        }
        
        
        
        else if (this->_color == "Magenta") {
            
            
            
            line8[0].position = sf::Vector2f(point[0][0], point[0][1]);
            
            
            
            line8[1].position = sf::Vector2f(point[1][0], point[1][1]);
            
            
            
            
            
            
            
            line8[0].color = sf::Color::Magenta;
            
            
            
            
            
            
            
            line8[1].color = sf::Color::Magenta;
            
            
            
        }
        
        
        
        
        
        
        
        else if (this->_color == "Black") {
            
            
            
            line8[0].position = sf::Vector2f(point[0][0], point[0][1]);
            
            
            
            line8[1].position = sf::Vector2f(point[1][0], point[1][1]);
            
            
            
            
            
            
            
            line8[0].color = sf::Color::Black;
            
            
            
            
            
            
            
            line8[1].color = sf::Color::Black;
            
            
            
        }
        
        
        
        else
            
            
            
        {
            
            
            
            line8[0].position = sf::Vector2f(point[0][0], point[0][1]);
            
            
            
            line8[1].position = sf::Vector2f(point[1][0], point[1][1]);
            
            
            
            
            
            
            
            line8[0].color = sf::Color::Black;
            
            
            
            
            
            
            
            line8[1].color = sf::Color::Black;
            
            
            
        }
        
        
        
        window.draw(line8);
        
        
        
        
        
        
        
        
        
        
        
    }
    
    
    
    int** contains(int** point) {
        
        
        
        
        
        
        
        set_points(point);
        
        
        
        return get_points();
        
        
        
    }
    
    
    
    void changeColour()
    
    
    
    {
        
        
        
        
        
        
        
    }
    
    
    
    
    
    
    
};



class curve :public openShape {
    
    
    
public:
    
    
    
    void draw() {
        
        
        
        int** point = get_points();
        
        
        
        int x_mid = (point[1][0] + point[0][0]) / 2;
        
        
        
        int x_mid2 = (x_mid + point[0][0]) / 2;
        
        
        
        int y_mid = (point[1][1] + point[0][1]) / 2;
        
        
        
        int mid_x3 = (point[1][0] + x_mid) / 2;
        
        
        
        int count = 0;
        
        
        
        cout << "x= " << point[0][0] << endl << "mid_x2= " << x_mid2 << endl;
        
        
        
        cout << "mid_x = " << x_mid << "mid_x3+ " << mid_x3 << endl;
        
        
        
        sf::Vertex vertex1[2000];
        
        
        
        float j = point[0][1];
        
        
        
        
        
        
        
        
        
        
        
        for (int i = point[0][0]; i <= x_mid2 && i >= point[0][0]; i++, j = j - 0.5) {
            
            
            
            
            
            
            
            vertex1[count].position = sf::Vector2f(i, j);
            
            
            
            vertex1[count].color = sf::Color::Red;
            
            
            
            sf::VertexArray pixel;
            
            
            
            pixel.append(vertex1[count]);
            
            
            
            window.draw(pixel);
            
            
            
            count++;
            
            
            
        }
        
        
        
        for (int i = x_mid2; i <= x_mid && i >= point[0][0]; i++, j = j + 0.5) {
            
            
            
            if (i < (x_mid + 20)) {
                
                
                
                j = j - 0.5;
                
                
                
                
                
                
                
            }
            
            
            
            vertex1[count].position = sf::Vector2f(i, j);
            
            
            
            vertex1[count].color = sf::Color::Red;
            
            
            
            sf::VertexArray pixel;
            
            
            
            pixel.append(vertex1[count]);
            
            
            
            window.draw(pixel);
            
            
            
            count++;
            
            
            
        }
        
        
        
        
        
        
        
        for (int i = x_mid; i <= mid_x3 && i >= point[0][0]; i++, j = j - 0.5) {
            
            
            
            if (i < (x_mid + 20)) {
                
                
                
                j = j + 0.5;
                
                
                
                
                
                
                
            }
            
            
            
            vertex1[count].position = sf::Vector2f(i, j);
            
            
            
            vertex1[count].color = sf::Color::Red;
            
            
            
            sf::VertexArray pixel;
            
            
            
            pixel.append(vertex1[count]);
            
            
            
            window.draw(pixel);
            
            
            
            count++;
            
            
            
        }
        
        
        
        
        
        
        
        for (int i = mid_x3; i <= point[1][0] && i >= point[0][0]; i++, j = j + 0.5) {
            
            
            
            if (i < (mid_x3 + 20)) {
                
                
                
                j = j - 0.5;
                
                
                
                
                
                
                
            }
            
            
            
            vertex1[count].position = sf::Vector2f(i, j);
            
            
            
            vertex1[count].color = sf::Color::Red;
            
            
            
            sf::VertexArray pixel;
            
            
            
            pixel.append(vertex1[count]);
            
            
            
            window.draw(pixel);
            
            
            
            count++;
            
            
            
        }
        
        
        
        
        
        
        
        
        
        
        
    }
    
    
    
    int** contains(int** point) {
        
        
        
        
        
        
        
        set_points(point);
        
        
        
        return get_points();
        
        
        
    }
    
    
    
    
    
    
    
    void changeColour()
    
    
    
    {
        
        
        
        
        
        
        
    }
    
    
    
};



class rrectangle : public polygon {
    
    
    
public:
    
    int** contains(int** point) {
        
        
        
        set_points(point);
        
        
        
        
        
        
        
        return get_points();
        
        
        
    }
    
    void draw() {
        
        
        
        int** rectangle_points = get_points();
        
        
        
        sf::VertexArray line4(sf::LineStrip, 2);
        
        
        
        sf::VertexArray line5(sf::LineStrip, 2);
        
        
        
        sf::VertexArray line6(sf::LineStrip, 2);
        
        int point2_x = rectangle_points[0][0];
        
        int point2_y = rectangle_points[1][1];
        
        int point4_x = rectangle_points[1][0];
        
        int point4_y = rectangle_points[0][1];
        
        
        
        sf::VertexArray line7(sf::LineStrip, 2);
        
        
        
        if (this->_color == "Red")
            
        {
            
            
            
            
            
            line4[0].position = sf::Vector2f(rectangle_points[0][0], rectangle_points[0][1]);
            
            
            
            
            
            
            
            line4[1].position = sf::Vector2f(point2_x, point2_y);
            
            
            
            
            
            
            
            line4[0].color = sf::Color::Red;
            
            
            
            
            
            
            
            line4[1].color = sf::Color::Red;
            
            
            
            
            
            
            
            line5[0].position = sf::Vector2f(point2_x, point2_y);
            
            
            
            
            
            
            
            line5[1].position = sf::Vector2f(rectangle_points[1][0], rectangle_points[1][1]);
            
            
            
            
            
            
            
            // cout << "===================rec===================" << rectangle_points[1][0] << endl;
            
            
            
            
            
            
            
            line5[0].color = sf::Color::Red;
            
            
            
            line5[1].color = sf::Color::Red;
            
            
            
            
            
            
            
            line6[0].position = sf::Vector2f(rectangle_points[1][0], rectangle_points[1][1]);
            
            
            
            
            
            
            
            line6[1].position = sf::Vector2f(point4_x, point4_y);
            
            
            
            
            
            
            
            line6[0].color = sf::Color::Red;
            
            
            
            line6[1].color = sf::Color::Red;
            
            
            
            
            
            
            
            line7[0].position = sf::Vector2f(point4_x, point4_y);
            
            
            
            
            
            
            
            line7[1].position = sf::Vector2f(rectangle_points[0][0], rectangle_points[0][1]);
            
            
            
            
            
            
            
            line7[0].color = sf::Color::Red;
            
            
            
            line7[1].color = sf::Color::Red;
            
            
            
            
            
            
            
        }
        
        
        
        else if (this->_color == "Green")
            
        {
            
            
            
            
            
            line4[0].position = sf::Vector2f(rectangle_points[0][0], rectangle_points[0][1]);
            
            
            
            
            
            
            
            line4[1].position = sf::Vector2f(point2_x, point2_y);
            
            
            
            
            
            
            
            line4[0].color = sf::Color::Green;
            
            
            
            
            
            
            
            line4[1].color = sf::Color::Green;
            
            
            
            
            
            
            
            line5[0].position = sf::Vector2f(point2_x, point2_y);
            
            
            
            
            
            
            
            line5[1].position = sf::Vector2f(rectangle_points[1][0], rectangle_points[1][1]);
            
            
            
            
            
            
            
            // cout << "===================rec===================" << rectangle_points[1][0] << endl;
            
            
            
            
            
            
            
            line5[0].color = sf::Color::Green;
            
            
            
            line5[1].color = sf::Color::Green;
            
            
            
            
            
            
            
            line6[0].position = sf::Vector2f(rectangle_points[1][0], rectangle_points[1][1]);
            
            
            
            
            
            
            
            line6[1].position = sf::Vector2f(point4_x, point4_y);
            
            
            
            
            
            
            
            line6[0].color = sf::Color::Green;
            
            
            
            line6[1].color = sf::Color::Green;
            
            
            
            
            
            
            
            line7[0].position = sf::Vector2f(point4_x, point4_y);
            
            
            
            
            
            
            
            line7[1].position = sf::Vector2f(rectangle_points[0][0], rectangle_points[0][1]);
            
            
            
            
            
            
            
            line7[0].color = sf::Color::Green;
            
            
            
            line7[1].color = sf::Color::Green;
            
            
            
            
            
            
            
        }
        
        else  if (this->_color == "Yellow")
            
        {
            
            
            
            
            
            line4[0].position = sf::Vector2f(rectangle_points[0][0], rectangle_points[0][1]);
            
            
            
            
            
            
            
            line4[1].position = sf::Vector2f(point2_x, point2_y);
            
            
            
            
            
            
            
            line4[0].color = sf::Color::Yellow;
            
            
            
            
            
            
            
            line4[1].color = sf::Color::Yellow;
            
            
            
            
            
            
            
            line5[0].position = sf::Vector2f(point2_x, point2_y);
            
            
            
            
            
            
            
            line5[1].position = sf::Vector2f(rectangle_points[1][0], rectangle_points[1][1]);
            
            
            
            
            
            
            
            // cout << "===================rec===================" << rectangle_points[1][0] << endl;
            
            
            
            
            
            
            
            line5[0].color = sf::Color::Yellow;
            
            
            
            line5[1].color = sf::Color::Yellow;
            
            
            
            
            
            
            
            line6[0].position = sf::Vector2f(rectangle_points[1][0], rectangle_points[1][1]);
            
            
            
            
            
            
            
            line6[1].position = sf::Vector2f(point4_x, point4_y);
            
            
            
            
            
            
            
            line6[0].color = sf::Color::Yellow;
            
            
            
            line6[1].color = sf::Color::Yellow;
            
            
            
            
            
            
            
            line7[0].position = sf::Vector2f(point4_x, point4_y);
            
            
            
            
            
            
            
            line7[1].position = sf::Vector2f(rectangle_points[0][0], rectangle_points[0][1]);
            
            
            
            
            
            
            
            line7[0].color = sf::Color::Yellow;
            
            
            
            line7[1].color = sf::Color::Yellow;
            
            
            
            
            
            
            
        }
        else if(this->_color == "White")
        {
            line4[0].position = sf::Vector2f(rectangle_points[0][0], rectangle_points[0][1]);
            
            
            
            
            
            
            
            line4[1].position = sf::Vector2f(point2_x, point2_y);
            
            
            
            
            
            
            
            line4[0].color = sf::Color::White;
            
            
            
            
            
            
            
            line4[1].color = sf::Color::White;
            
            
            
            
            
            
            
            line5[0].position = sf::Vector2f(point2_x, point2_y);
            
            
            
            
            
            
            
            line5[1].position = sf::Vector2f(rectangle_points[1][0], rectangle_points[1][1]);
            
            
            
            
            
            
            
            // cout << "===================rec===================" << rectangle_points[1][0] << endl;
            
            
            
            
            
            
            
            line5[0].color = sf::Color::White;
            
            
            
            line5[1].color = sf::Color::White;
            
            
            
            
            
            
            
            line6[0].position = sf::Vector2f(rectangle_points[1][0], rectangle_points[1][1]);
            
            
            
            
            
            
            
            line6[1].position = sf::Vector2f(point4_x, point4_y);
            
            
            
            
            
            
            
            line6[0].color = sf::Color::White;
            
            
            
            line6[1].color = sf::Color::White;
            
            
            
            
            
            
            
            line7[0].position = sf::Vector2f(point4_x, point4_y);
            
            
            
            
            
            
            
            line7[1].position = sf::Vector2f(rectangle_points[0][0], rectangle_points[0][1]);
            
            
            
            
            
            
            
            line7[0].color = sf::Color::White;
            
            
            
            line7[1].color = sf::Color::White;
            
            
            
        }
        
        
        else if (this->_color == "Blue")
            
        {
            
            
            
            
            
            line4[0].position = sf::Vector2f(rectangle_points[0][0], rectangle_points[0][1]);
            
            
            
            
            
            
            
            line4[1].position = sf::Vector2f(point2_x, point2_y);
            
            
            
            
            
            
            
            line4[0].color = sf::Color::Blue;
            
            
            
            
            
            
            
            line4[1].color = sf::Color::Blue;
            
            
            
            
            
            
            
            line5[0].position = sf::Vector2f(point2_x, point2_y);
            
            
            
            
            
            
            
            line5[1].position = sf::Vector2f(rectangle_points[1][0], rectangle_points[1][1]);
            
            
            
            
            
            
            
            // cout << "===================rec===================" << rectangle_points[1][0] << endl;
            
            
            
            
            
            
            
            line5[0].color = sf::Color::Blue;
            
            
            
            line5[1].color = sf::Color::Blue;
            
            
            
            
            
            
            
            line6[0].position = sf::Vector2f(rectangle_points[1][0], rectangle_points[1][1]);
            
            
            
            
            
            
            
            line6[1].position = sf::Vector2f(point4_x, point4_y);
            
            
            
            
            
            
            
            line6[0].color = sf::Color::Blue;
            
            
            
            line6[1].color = sf::Color::Blue;
            
            
            
            
            
            
            
            line7[0].position = sf::Vector2f(point4_x, point4_y);
            
            
            
            
            
            
            
            line7[1].position = sf::Vector2f(rectangle_points[0][0], rectangle_points[0][1]);
            
            
            
            
            
            
            
            line7[0].color = sf::Color::Blue;
            
            
            
            line7[1].color = sf::Color::Blue;
            
            
            
            
            
            
            
        }
        
        
        
        
        
        else if (this->_color == "Magenta")
            
        {
            
            
            
            
            
            line4[0].position = sf::Vector2f(rectangle_points[0][0], rectangle_points[0][1]);
            
            
            
            
            
            
            
            line4[1].position = sf::Vector2f(point2_x, point2_y);
            
            
            
            
            
            
            
            line4[0].color = sf::Color::Magenta;
            
            
            
            
            
            
            
            line4[1].color = sf::Color::Magenta;
            
            
            
            
            
            
            
            line5[0].position = sf::Vector2f(point2_x, point2_y);
            
            
            
            
            
            
            
            line5[1].position = sf::Vector2f(rectangle_points[1][0], rectangle_points[1][1]);
            
            
            
            
            
            
            
            // cout << "===================rec===================" << rectangle_points[1][0] << endl;
            
            
            
            
            
            
            
            line5[0].color = sf::Color::Magenta;
            
            
            
            line5[1].color = sf::Color::Magenta;
            
            
            
            
            
            
            
            line6[0].position = sf::Vector2f(rectangle_points[1][0], rectangle_points[1][1]);
            
            
            
            
            
            
            
            line6[1].position = sf::Vector2f(point4_x, point4_y);
            
            
            
            
            
            
            
            line6[0].color = sf::Color::Magenta;
            
            
            
            line6[1].color = sf::Color::Magenta;
            
            
            
            
            
            
            
            line7[0].position = sf::Vector2f(point4_x, point4_y);
            
            
            
            
            
            
            
            line7[1].position = sf::Vector2f(rectangle_points[0][0], rectangle_points[0][1]);
            
            
            
            
            
            
            
            line7[0].color = sf::Color::Magenta;
            
            
            
            line7[1].color = sf::Color::Magenta;
            
            
            
            
            
            
            
        }
        
        
        
        else if (this->_color == "Grey")
            
        {
            
            
            
            
            
            line4[0].position = sf::Vector2f(rectangle_points[0][0], rectangle_points[0][1]);
            
            
            
            
            
            
            
            line4[1].position = sf::Vector2f(point2_x, point2_y);
            
            
            
            
            
            
            
            line4[0].color = sf::Color(192, 192, 192);
            
            
            
            
            
            
            
            line4[1].color = sf::Color(192, 192, 192);
            
            
            
            
            
            
            
            line5[0].position = sf::Vector2f(point2_x, point2_y);
            
            
            
            
            
            
            
            line5[1].position = sf::Vector2f(rectangle_points[1][0], rectangle_points[1][1]);
            
            
            
            
            
            
            
            // cout << "===================rec===================" << rectangle_points[1][0] << endl;
            
            
            
            
            
            
            
            line5[0].color = sf::Color(192, 192, 192);
            
            
            
            line5[1].color = sf::Color(192, 192, 192);
            
            
            
            
            
            
            
            line6[0].position = sf::Vector2f(rectangle_points[1][0], rectangle_points[1][1]);
            
            
            
            
            
            
            
            line6[1].position = sf::Vector2f(point4_x, point4_y);
            
            
            
            
            
            
            
            line6[0].color = sf::Color(192, 192, 192);
            
            
            
            line6[1].color = sf::Color(192, 192, 192);
            
            
            
            
            
            
            
            line7[0].position = sf::Vector2f(point4_x, point4_y);
            
            
            
            
            
            
            
            line7[1].position = sf::Vector2f(rectangle_points[0][0], rectangle_points[0][1]);
            
            
            
            
            
            
            
            line7[0].color = sf::Color(192, 192, 192);
            
            
            
            line7[1].color = sf::Color(192, 192, 192);
            
            
            
            
            
            
            
        }
        
        
        
        else if (this->_color == "Black")
            
        {
            
            
            
            
            
            line4[0].position = sf::Vector2f(rectangle_points[0][0], rectangle_points[0][1]);
            
            
            
            
            
            
            
            line4[1].position = sf::Vector2f(point2_x, point2_y);
            
            
            
            
            
            
            
            line4[0].color = sf::Color::Black;
            
            
            
            
            
            
            
            line4[1].color = sf::Color::Black;
            
            
            
            
            
            
            
            line5[0].position = sf::Vector2f(point2_x, point2_y);
            
            
            
            
            
            
            
            line5[1].position = sf::Vector2f(rectangle_points[1][0], rectangle_points[1][1]);
            
            
            
            
            
            
            
            // cout << "===================rec===================" << rectangle_points[1][0] << endl;
            
            
            
            
            
            
            
            line5[0].color = sf::Color::Black;
            
            
            
            line5[1].color = sf::Color::Black;
            
            
            
            
            
            
            
            line6[0].position = sf::Vector2f(rectangle_points[1][0], rectangle_points[1][1]);
            
            
            
            
            
            
            
            line6[1].position = sf::Vector2f(point4_x, point4_y);
            
            
            
            
            
            
            
            line6[0].color = sf::Color::Black;
            
            
            
            line6[1].color = sf::Color::Black;
            
            
            
            
            
            
            
            line7[0].position = sf::Vector2f(point4_x, point4_y);
            
            
            
            
            
            
            
            line7[1].position = sf::Vector2f(rectangle_points[0][0], rectangle_points[0][1]);
            
            
            
            
            
            
            
            line7[0].color = sf::Color::Black;
            
            
            
            line7[1].color = sf::Color::Black;
            
            
            
            
            
            
            
        }
        
        
        
        
        
        
        
        else
            
        {
            
            
            
            
            
            line4[0].position = sf::Vector2f(rectangle_points[0][0], rectangle_points[0][1]);
            
            
            
            
            
            
            
            line4[1].position = sf::Vector2f(point2_x, point2_y);
            
            
            
            
            
            
            
            line4[0].color = sf::Color::Black;
            
            
            
            
            
            
            
            line4[1].color = sf::Color::Black;
            
            
            
            
            
            
            
            line5[0].position = sf::Vector2f(point2_x, point2_y);
            
            
            
            
            
            
            
            line5[1].position = sf::Vector2f(rectangle_points[1][0], rectangle_points[1][1]);
            
            
            
            
            
            
            
            // cout << "===================rec===================" << rectangle_points[1][0] << endl;
            
            
            
            
            
            
            
            line5[0].color = sf::Color::Black;
            
            
            
            line5[1].color = sf::Color::Black;
            
            
            
            
            
            
            
            line6[0].position = sf::Vector2f(rectangle_points[1][0], rectangle_points[1][1]);
            
            
            
            
            
            
            
            line6[1].position = sf::Vector2f(point4_x, point4_y);
            
            
            
            
            
            
            
            line6[0].color = sf::Color::Black;
            
            
            
            line6[1].color = sf::Color::Black;
            
            
            
            
            
            
            
            line7[0].position = sf::Vector2f(point4_x, point4_y);
            
            
            
            
            
            
            
            line7[1].position = sf::Vector2f(rectangle_points[0][0], rectangle_points[0][1]);
            
            
            
            
            
            
            
            line7[0].color = sf::Color::Black;
            
            
            
            line7[1].color = sf::Color::Black;
            
            
            
            
            
            
            
        }
        
        
        
        window.draw(line4);
        
        
        
        window.draw(line5);
        
        
        
        window.draw(line6);
        
        
        
        window.draw(line7);
        
        
        
    }
    
    void fill(int color) {
        
        
        
        int** rectangle_points = get_points();
        
        int point2_x = rectangle_points[0][0];
        
        int point2_y = rectangle_points[1][1];
        
        int point4_x = rectangle_points[1][0];
        
        int point4_y = rectangle_points[0][1];
        
        cout << "=====================fill Rectangle======================" << endl;
        
        cout << "--------------------- COLOUR : " << _color << " --------------------" << endl;
        
        sf::VertexArray shade;
        
        sf::Vertex pixel;
        
        if (_color == "Red") {
            
            // sf::VertexArray shade ;
            
            
            
            pixel.color = sf::Color::Red;
            
            for (int i = 0; i < 2000; i++)
                
            {
                
                for (int j = 0; j < 1400; j++)
                    
                {
                    
                    pixel.position = sf::Vector2f(i, j);
                    
                    
                    
                    if (j >= rectangle_points[0][1] && j <= rectangle_points[1][1]) {
                        
                        
                        
                        if (i >= rectangle_points[0][0] && i <= rectangle_points[1][0]) {
                            
                            
                            
                            shade.append(pixel);
                            
                        }
                        
                    }
                    
                }
                
            }
            
            
            
        }
        
        else if (_color == "Yellow") {
            
            // sf::VertexArray shade ;
            
            
            
            pixel.color = sf::Color::Yellow;
            
            for (int i = 0; i < 2000; i++)
                
            {
                
                for (int j = 0; j < 1400; j++)
                    
                {
                    
                    pixel.position = sf::Vector2f(i, j);
                    
                    
                    
                    if (j >= rectangle_points[0][1] && j <= rectangle_points[1][1]) {
                        
                        
                        
                        if (i >= rectangle_points[0][0] && i <= rectangle_points[1][0]) {
                            
                            
                            
                            shade.append(pixel);
                            
                        }
                        
                    }
                    
                }
                
            }
            
            
            
        }
        
        else if (_color == "Blue") {
            
            // sf::VertexArray shade ;
            
            pixel.color = sf::Color::Blue;
            
            for (int i = 0; i < 2000; i++)
                
            {
                
                for (int j = 0; j < 1400; j++)
                    
                {
                    
                    pixel.position = sf::Vector2f(i, j);
                    
                    
                    
                    if (j >= rectangle_points[0][1] && j <= rectangle_points[1][1]) {
                        
                        
                        
                        if (i >= rectangle_points[0][0] && i <= rectangle_points[1][0]) {
                            
                            
                            
                            shade.append(pixel);
                            
                        }
                        
                    }
                    
                }
                
            }
            
            
            
            
            
        }
        
        else if (_color == "Green") {
            
            // sf::VertexArray shade ;
            
            
            
            pixel.color = sf::Color::Green;
            
            for (int i = 0; i < 2000; i++)
                
            {
                
                for (int j = 0; j < 1400; j++)
                    
                {
                    
                    pixel.position = sf::Vector2f(i, j);
                    
                    
                    
                    if (j >= rectangle_points[0][1] && j <= rectangle_points[1][1]) {
                        
                        
                        
                        if (i >= rectangle_points[0][0] && i <= rectangle_points[1][0]) {
                            
                            
                            
                            shade.append(pixel);
                            
                        }
                        
                    }
                    
                }
                
            }
            
            
            
        }
        
        else if (_color == "Grey")
    {
            
            // sf::VertexArray shade ;
            
            
            
            pixel.color = sf::Color(192, 192, 192);
            
            for (int i = 0; i < 2000; i++)
                
            {
                
                for (int j = 0; j < 1400; j++)
                    
                {
                    
                    pixel.position = sf::Vector2f(i, j);
                    
                    
                    
                    if (j >= rectangle_points[0][1] && j <= rectangle_points[1][1]) {
                        
                        
                        
                        if (i >= rectangle_points[0][0] && i <= rectangle_points[1][0]) {
                            
                            
                            
                            shade.append(pixel);
                            
                        }
                        
                    }
                    
                }
                
            }
            
            
            
        }
        
        else if (_color == "Magenta") {
            
            // sf::VertexArray shade ;
            
            
            
            pixel.color = sf::Color::Magenta;
            
            for (int i = 0; i < 2000; i++)
                
            {
                
                for (int j = 0; j < 1400; j++)
                    
                {
                    
                    pixel.position = sf::Vector2f(i, j);
                    
                    
                    
                    if (j >= rectangle_points[0][1] && j <= rectangle_points[1][1]) {
                        
                        
                        
                        if (i >= rectangle_points[0][0] && i <= rectangle_points[1][0]) {
                            
                            
                            
                            shade.append(pixel);
                            
                        }
                        
                    }
                    
                }
                
            }
            
            
            
        }
        else if (_color == "White") {
            
            // sf::VertexArray shade ;
            
            
            
            pixel.color = sf::Color::White;
            
            for (int i = 0; i < 2000; i++)
                
            {
                
                for (int j = 0; j < 1400; j++)
                    
                {
                    
                    pixel.position = sf::Vector2f(i, j);
                    
                    
                    
                    if (j >= rectangle_points[0][1] && j <= rectangle_points[1][1]) {
                        
                        
                        
                        if (i >= rectangle_points[0][0] && i <= rectangle_points[1][0]) {
                            
                            
                            
                            shade.append(pixel);
                            
                        }
                        
                    }
                    
                }
                
            }
            
            
            
        }
        else if (_color == "Black") {
            
            // sf::VertexArray shade ;
            
            
            
            pixel.color = sf::Color::Black;
            
            for (int i = 0; i < 2000; i++)
                
            {
                
                for (int j = 0; j < 1400; j++)
                    
                {
                    
                    pixel.position = sf::Vector2f(i, j);
                    
                    
                    
                    if (j >= rectangle_points[0][1] && j <= rectangle_points[1][1]) {
                        
                        
                        
                        if (i >= rectangle_points[0][0] && i <= rectangle_points[1][0]) {
                            
                            
                            
                            shade.append(pixel);
                            
                        }
                        
                    }
                    
                }
                
            }
            
            
            
        }
        
        
        
        window.draw(shade);
        
    }
    
    
    
};



class Triangle : public polygon {
    
    
    
public:
    
    
    
    int** contains(int** point) {
        
        
        
        // set_no_of_points(3);
        
        
        
        set_points(point);
        
        
        
        return get_points();
        
        
        
    }
    
    
    
    void draw() {
        
        
        
        
        
        
        
        sf::VertexArray line1(sf::LineStrip, 2);
        
        
        
        sf::VertexArray line2(sf::LineStrip, 2);
        
        
        
        sf::VertexArray line3(sf::LineStrip, 2);
        
        
        
        int** point = get_points();
        
        
        
        line1[0].position = sf::Vector2f(point[0][0], point[0][1]);
        
        
        
        line1[1].position = sf::Vector2f(point[1][0], point[1][1]);
        
        
        
        //  cout << "print " << point[0][0] <<"  " <<point[0][1];
        
        
        
        
        
        
        
        line1[0].color = sf::Color::Black;
        
        
        
        line1[1].color = sf::Color::Black;
        
        
        
        
        
        
        
        
        
        
        
        line2[0].position = sf::Vector2f(point[1][0], point[1][1]);
        
        
        
        line2[1].position = sf::Vector2f(point[2][0], point[2][1]);
        
        
        
        
        
        
        
        
        
        
        
        line2[0].color = sf::Color::Black;
        
        
        
        line2[1].color = sf::Color::Black;
        
        
        
        
        
        
        
        
        
        
        
        line3[0].position = sf::Vector2f(point[2][0], point[2][1]);
        
        
        
        line3[1].position = sf::Vector2f(point[0][0], point[0][1]);
        
        
        
        
        
        
        
        
        
        
        
        line3[0].color = sf::Color::Black;
        
        
        
        line3[1].color = sf::Color::Black;
        
        
        
        
        
        
        
        
        
        
        
        window.draw(line1);
        
        
        
        window.draw(line2);
        
        
        
        window.draw(line3);
        
        
        
    }
    
    
    
    void fill(int color) {
        
        
        
        
        
        
    }
    
    
    
};



class Text :virtual public Shapes {
    
    
    
    
    
    
    
public:
    
    
    
    void changeColour();
    
    
    
    void draw();
    
    
    
    int** contains(int** points);
    
    
    
};



int main()
{
    
    
    std::string str ;
    sf::String text12 ;
    sf::Font font12 ;
    sf::Text text11 ;
    
    int rectangle_clr[20] = { 0 };
    cout << "----------------------------* WELCOME TO AF PAINTS *--------------------------------" << endl;
    
    cout << "1.To load file enter 1." << endl;
    
    cout << "2.To do painting yourself enter 2." << endl;
    
    int choice;
    
    cout << "Enter choice: ";
    
    cin >> choice;
    
    if (choice == 1) {
        
        int x_, y_, z_;
        
        int num_polygon;
        
        string shapee;
        
        int **arr_circle=new int *[5];
        for(int i=0 ; i<5 ; i++)
        {
            arr_circle[i]=new int ;
        }
        int **arr_rectangle=new int *[5];
        for(int i=0 ; i<5 ; i++)
        {
            arr_rectangle[i]=new int ;
        }
        int **arr_line=new int *[5];
        for(int i=0 ; i<5 ; i++)
        {
            arr_line[i]=new int ;
        }
        int **arr_curve=new int *[5];
        for(int i=0 ; i<5 ; i++)
        {
            arr_curve[i]=new int ;
        }
        ifstream in("Paint_input.txt");
        
        if (in.is_open())
            
        {
            
            while (!in.eof())
                
            {
                
                if (shapee == "Cirlce" || shapee == "Line" || shapee == "Curve" || shapee == "Rectangle")
                    
                {
                    
                    in >> x_;
                    
                    in >> y_;
                    
                    cout << shapee << " : " << endl << "x :" << x_ << endl << "y : " << y_ << endl;
                    
                    circle ch;
                    
                    int** arr = new int* [2];
                      
                }
                
                else if (shapee == "Triangle") {
                    
                    in >> x_;
                    
                    in >> y_;
                    
                    in >> z_;
                    
                    cout << shapee << " : " << endl << "x :" << x_ << endl << "y : " << y_ << endl << "z : " << z_ << endl;
                    
                }
                
                else if (shapee == "Polygon") {
                    
                    in >> num_polygon;
                    
                    cout << shapee << " :" << endl << "x \t y" << endl;
                    
                    int** arr = new int* [num_polygon + 1];
                    
                    for (int i = 0; i <= num_polygon; i++) {
                        
                        arr[i] = new int[2];
                        
                        
                        
                        
                        
                    }
                    
                    for (int i = 0; i <= num_polygon; i++) {
                        
                        
                        
                        for (int j = 0; j < 2; j++) {
                            
                            in >> arr[i][j];
                            
                            cout << arr[i][j] << "\t";
                            
                            
                            
                        }
                        
                        cout << endl;
                        
                    }
                    
                    
                    
                    
                    
                }
                
                
                
            }
            
        }
        
        else
            
            cout << "UNABLE TO OPEN FILE!" << endl;
        
        
        
        
        
    }
    
    else if (choice == 2) {
        
        bool black_pressed = false;
        
        int circle_clr[20] = { 0 };
        
        
        
        int kuchbhi;
        
        
        
        int counttttt = 0;
        
        
        
        int curve_count = 0;
        
        
        
        int** curve_points;
        
        
        
        bool curve_press = false;
        
        
        
        curve** c_curve=new curve*[20];
        for (int i = 0; i < 20; i++) {
            c_curve[i] = new curve;
        }
        
        
        
        curve_points = new int* [20];
        
        
        
        for (int i = 0; i < 20; i++) {
            
            
            
            curve_points[i] = new int[2];
            
            
            
        }
        
        
        
        
        
        
        
        bool paint_pressed = false;
        
        
        
        
        
        
        
        
        
        
        
        int akbarr = 0;
        
        
        
        bool c_check = false;
        
        
        
        int** check_circle;
        
        
        
        int** check_curve;
        
        
        
        check_circle = new int* [20];
        
        
        
        for (int i = 0; i < 20; i++)
        {
            
            
            
            check_circle[i] = new int[2];
            
            
            
        }
        
        
        
        int c_radius;
        
        
        
        check_curve = new int* [20];
        
        
        
        for (int i = 0; i < 20; i++)
            
            
            
        {
            
            
            
            check_curve[i] = new int[2];
            
            
            
        }
        
        
        
        int cc_count = 0;
        
        
        
        int ccurve_count = 0;
        
        
        
        int x_circle, y_circle;
        
        
        
        sf::Event event;
        
        
        
        bool tripressed = false;
        
        
        
        //  int tx1, ty1, tx2, ty2, tx3, ty3;
        
        
        
        int triclick = 0;
        
        
        
        Triangle **t=new Triangle*[20];
        for (int i = 0; i < 20; i++) {
            
            t[i] = new Triangle;
        }
        
        
        
        rrectangle **r=new rrectangle*[20];
        for (int i = 0; i < 20; i++) {
            
            r[i] = new rrectangle;
        }
        
        
        
        polygon **polyy=new polygon*[20];
        
        for (int i = 0; i < 20; i++) {
            
            polyy[i] = new polygon;
            
        }
        
        
        int rr = 0;
        
        
        
        int** rectangle_points;
        
        
        
        rectangle_points = new int* [2];
        
        
        
        for (int i = 0; i < 2; i++) {
            
            
            
            rectangle_points[i] = new int[2];
            
            
            
        }
        
        
        
        int** poly_check;
        
        
        
        poly_check = new int* [2];
        
        
        
        for (int i = 0; i < 22; i++) {
            
            
            
            poly_check[i] = new int[2];
            
            
            
        }
        
        
        
        int tt = 0;
        
        
        
        int recclick = 0;
        
        bool text_pressed=false ;
        
        int poly_click = 0;
        
        
        
        bool recpressed = false;
        
        
        
        bool poly_press = false;
        
        
        
        int rx1, ry1, rx2, ry2, rx3, ry3, rx4, ry4;
        
        
        
        bool pressed = false;
        
        
        
        int** poly_points;
        
        
        
        poly_points = new int* [2];
        
        
        
        for (int i = 0; i < 2; i++) {
            
            
            
            
            
            
            
            poly_points[i] = new int;
            
            
            
        }
        
        
        
        
        
        
        
        // float _radius ;
        
        
        
        
        
        
        
        
        
        
        
        int** circle_points;
        
        
        
        circle_points = new int* [2];
        
        
        
        for (int i = 0; i < 2; i++)
            
            
            
        {
            
            
            
            circle_points[i] = new int[2];
            
            
            
        }
        
        
        
        
        
        
        
        int** triangle_points;
        
        
        
        triangle_points = new int* [10];
        
        
        
        for (int i = 0; i < 3; i++) {
            
            
            
            triangle_points[i] = new int[2];
            
            
            
        }
        
        
        
        bool linepressed = false;
        
        
        
        int lineclick = 0;
        
        
        
        line** li=new line*[20];
        for (int i = 0; i < 20; i++) {
            
            li[i] = new line;
        }
        
        
        
        
        
        
        int** line_points;
        
        
        
        line_points = new int* [2];
        
        
        
        for (int i = 0; i < 2; i++)
            
            
            
        {
            
            
            
            line_points[i] = new int[2];
            
            
            
        }
        
        
        
        int ll = 0;
        
        
        
        float x1, y1;
        
        
        
        sf::CircleShape shape1;
        
        
        
        /*shape.setOutlineThickness(4);
         
         
         
         shape.setOutlineColor(sf::Color(0,0,0));
         
         
         
         shape.setPosition(300, 400);*/
        
        
        
        int sub;
        
        
        
        int x, y, X, Y;
        
        
        
        int click = 0;
        
        
        
        circle **c=new circle*[20];
        for (int i = 0; i < 20; i++) {
            
            c[i] = new circle;
        }
        
        
        
        int cc = 0;
        
        
        
        int cc_curve = 0;
        
        
        
        bool eraserpressed = false;
        
        
        
        int ex, ey;
        
        
        
        int eraseclick = 0;
        
        
        
        int curve_click = 0;
        
        
        
        int poly_count = 0;
        
        
        
        sf::RectangleShape black(sf::Vector2f(50.0f, 50.0f));
        
        
        
        black.setFillColor(sf::Color::Black);
        
        
        
        black.setPosition(30, 50);
        
        
        
        // Create the main window
        
        
        
        
        
        
        
        sf::RectangleShape yellow(sf::Vector2f(50.0f, 50.0f));
        
        
        
        yellow.setFillColor(sf::Color::Yellow);
        
        
        
        yellow.setPosition(30, 100);
        
        
        
        
        
        
        
        sf::RectangleShape blue(sf::Vector2f(50.0f, 50.0f));
        
        
        
        blue.setFillColor(sf::Color::Blue);
        
        
        
        blue.setPosition(30, 150);
        
        
        
        
        
        
        
        sf::RectangleShape green(sf::Vector2f(50.0f, 50.0f));
        
        
        
        green.setFillColor(sf::Color::Green);
        
        
        
        green.setPosition(30, 200);
        
        
        
        
        
        
        
        sf::RectangleShape red(sf::Vector2f(50.0f, 50.0f));
        
        
        
        red.setFillColor(sf::Color::Red);
        
        
        
        red.setPosition(30, 250);
        
        
        
        
        
        
        
        sf::RectangleShape grey(sf::Vector2f(50.0f, 50.0f));
        
        
        
        grey.setFillColor(sf::Color(192, 192, 192));
        
        
        
        grey.setPosition(30, 300);
        
        
        
        
        
        
        
        sf::RectangleShape magenta(sf::Vector2f(50.0f, 50.0f));
        
        
        
        magenta.setFillColor(sf::Color::Magenta);
        
        
        
        magenta.setPosition(30, 350);
        
        
        
        
        
        
        
        sf::RectangleShape paintbox(sf::Vector2f(50.0f, 50.0f));
        
        
        
        sf::Texture bucket;
        
        
        
        bucket.loadFromFile(resourcePath() + "paint-bucket.png");
        
        
        
        paintbox.setTexture(&bucket);
        
        
        
        paintbox.setPosition(30, 450);
        
        
        
        paintbox.setTexture(&bucket);
        
        
        
        
        
        
        
        sf::RectangleShape circle(sf::Vector2f(50.0f, 50.0f));
        
        
        
        sf::Texture c1;
        
        
        
        c1.loadFromFile(resourcePath() + "rec.png");
        
        
        
        circle.setTexture(&c1);
        
        
        
        circle.setPosition(30, 530);
        
        
        
        circle.setTexture(&c1);
        
        
        
        
        
        
        
        sf::RectangleShape triangle(sf::Vector2f(50.0f, 50.0f));
        
        
        
        sf::Texture t1;
        
        
        
        t1.loadFromFile(resourcePath() + "bleach.png");
        
        
        
        triangle.setTexture(&t1);
        
        
        
        triangle.setPosition(30, 610);
        
        
        
        triangle.setTexture(&t1);
        
        
        
        
        
        
        
        sf::RectangleShape rectangle(sf::Vector2f(50.0f, 50.0f));
        
        
        
        sf::Texture r1;
        
        
        
        r1.loadFromFile(resourcePath() + "rectangle.png");
        
        
        
        rectangle.setTexture(&r1);
        
        
        
        rectangle.setPosition(30, 690);
        
        
        
        rectangle.setTexture(&r1);
        
        
        
        
        
        
        
        sf::RectangleShape line(sf::Vector2f(50.0f, 50.0f));
        
        
        
        sf::Texture l;
        
        
        
        l.loadFromFile(resourcePath() + "substract.png");
        
        
        
        line.setTexture(&l);
        
        
        
        line.setPosition(30, 770);
        
        
        
        line.setTexture(&l);
        
        
        
        
        
        
        
        sf::RectangleShape eraser(sf::Vector2f(50.0f, 50.0f));
        
        
        
        sf::Texture e;
        
        
        
        e.loadFromFile(resourcePath() + "eraser.png");
        
        
        
        eraser.setTexture(&e);
        
        
        
        eraser.setPosition(30, 850);
        
        
        
        eraser.setTexture(&e);
        
        
        
        
        
        
        
        sf::RectangleShape curve(sf::Vector2f(50.0f, 50.0f));
        
        
        
        sf::Texture curve1;
        
        
        
        curve1.loadFromFile(resourcePath() + "vector-curve-line.png");
        
        
        
        curve.setTexture(&curve1);
        
        
        
        curve.setPosition(30, 930);
        
        
        
        curve.setTexture(&curve1);
        
        
        
        
        
        
        
        sf::RectangleShape pol(sf::Vector2f(50.0f, 50.0f));
        
        
        
        sf::Texture poly;
        
        
        
        poly.loadFromFile(resourcePath() + "hexagon.png");
        
        
        
        pol.setTexture(&poly);
        
        
        
        pol.setPosition(30, 1020);
        
        
        
        pol.setTexture(&poly);
        
        
        sf::RectangleShape text(sf::Vector2f(50.0f, 50.0f));
        
        
        
        sf::Texture text1;
        
        
        
        text1.loadFromFile(resourcePath() + "font.png");
        
        
        
        text.setTexture(&text1);
        
        
        
        text.setPosition(30, 1110);
        
        
        
        text.setTexture(&text1);
        
        
        
        
        // Start the game loop
        
        
        
        while (window.isOpen())
            
            
            
        {
            
            
            
            // Process events
            
            
            
            //sf::Event event;
            
            
            
            
            
            
            
            while (window.pollEvent(event))
                
                
                
            {
                
                
                
                // Close window: exit
                
                
                
                switch (event.type)
                    
                    
                    
                {
                        
                        
                        
                    case sf::Event::Closed:
                        
                        
                        
                        window.close();
                        
                        
                        
                        break;
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        // Escape pressed: exit
                        
                        
                        
                        
                        
                        
                        
                    case sf::Event::KeyPressed:
                        
                        
                        
                        window.close();
                        
                        
                        
                        break;
                        
                        
                        
                        
                        
                        
                        
                    case sf::Event::MouseButtonPressed:
                        
                        
                        
                        
                        
                        
                        
                        if (event.mouseButton.x > 30 && event.mouseButton.x <= 80 && event.mouseButton.y > 50 && event.mouseButton.y <= 100)
                            
                            
                            
                        {
                            
                            
                            
                            pressed = false;
                            
                            
                            
                            black_pressed = true;
                            
                            
                            
                            rectangle.setOutlineThickness(5);
                            
                            
                            
                            rectangle.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            black.setOutlineThickness(5);
                            
                            
                            
                            black.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            circle.setOutlineThickness(5);
                            
                            
                            
                            circle.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            
                            
                            
                            
                            triangle.setOutlineThickness(5);
                            
                            
                            
                            triangle.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            circle.setOutlineThickness(5);
                            
                            
                            
                            circle.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            line.setOutlineThickness(5);
                            
                            
                            
                            line.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            
                            
                            
                            
                            eraser.setOutlineThickness(5);
                            
                            
                            
                            eraser.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            paintbox.setOutlineThickness(5);
                            
                            
                            
                            paintbox.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            
                            
                            
                            
                            magenta.setOutlineThickness(5);
                            
                            
                            
                            magenta.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            grey.setOutlineThickness(5);
                            
                            
                            
                            grey.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            curve.setOutlineThickness(5);
                            
                            
                            
                            curve.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            
                            
                            
                            
                            pol.setOutlineThickness(5);
                            
                            
                            
                            pol.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            red.setOutlineThickness(5);
                            
                            
                            
                            red.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            text.setOutlineThickness(5);
                             
                            text.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            green.setOutlineThickness(5);
                            
                            
                            
                            green.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            
                            
                            
                            
                            blue.setOutlineThickness(5);
                            
                            
                            
                            blue.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            
                            
                            
                            
                            yellow.setOutlineThickness(5);
                            
                            
                            
                            yellow.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            
                            
                            
                            
                            black.setOutlineThickness(5);
                            
                            
                            
                            black.setOutlineColor(sf::Color(30, 80, 530));
                            
                            
                            
                            break;
                            
                            
                            
                        }
                        
                        
                        
                        if (black_pressed == true )
                            
                            
                            
                        {
                            
                            
                            
                            // if (triclick > 3) {
                            
                            
                            
                            // for (int i = 0; i < tt; i++)
                            
                            
                            if(pressed==false && recpressed==false && tripressed==true )
                            {
                                pressed=false ;
                                recpressed=false;
                                tripressed=true ;
                            t[tt]->_color = "Black";
                            }
                            
                            
                            
                            
                            
                            
                            //  }//
                            
                            
                            
                            // if (click > 2) {
                            
                            
                            
                            
                            
                            
                            
                            
                            if(pressed==true && recpressed==false && tripressed==false )
                            {
                               // pressed=true;
                                recpressed=false ;
                                tripressed=false;
                            if (cc - 1 >= 0)
                                
                                c[cc - 1]->_color = "Black";
                            }
                            
                            
                            //c[cc]._color="Black";
                            
                            
                            
                            
                            
                            
                            
                            // }
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            // if (recclick > 4) {
                            
                            
                            
                            
                            
                            
                            
                            
                            if(pressed==false && recpressed==true && tripressed==false )
                            {
                                pressed=false;
                                recpressed=true ;
                                tripressed=false;
                            if (rr - 1 >= 0)
                                
                                r[rr - 1]->_color = "Black";
                            
                            }
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            // }
                            
                            
                            
                            //  if (lineclick > 2) {
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            li[ll]->_color = "Black";
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            //  }
                            
                            
                            
                            // if (curve_click > 2) {
                            
                            
                            
                            
                            
                            
                            
                            // for (int i = 0; i < ccurve_count; i++) {
                            
                            
                            
                            
                            
                            
                            
                            c_curve[ccurve_count]->_color = "Black";
                            
                            
                            
                            
                            
                            
                            
                            // }
                            
                            
                            
                            
                            
                            
                            
                            // }
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                        }
                        
                        
                        
                        if (event.mouseButton.x > 30 && event.mouseButton.x <= 80 && event.mouseButton.y > 100 && event.mouseButton.y <= 150)
                            
                            
                            
                        {
                            
                            
                            
                            
                            
                            
                            
                            rectangle.setOutlineThickness(5);
                            
                            
                            
                            rectangle.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            black.setOutlineThickness(5);
                            
                            
                            
                            black.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            circle.setOutlineThickness(5);
                            
                            
                            
                            circle.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            black.setOutlineThickness(5);
                            
                            
                            
                            black.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            
                            
                            
                            
                            triangle.setOutlineThickness(5);
                            
                            
                            
                            triangle.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            circle.setOutlineThickness(5);
                            
                            
                            
                            circle.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            
                            
                            
                            
                            paintbox.setOutlineThickness(5);
                            
                            
                            
                            paintbox.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            line.setOutlineThickness(5);
                            
                            
                            
                            line.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            curve.setOutlineThickness(5);
                            
                            
                            
                            curve.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            
                            
                            
                            
                            pol.setOutlineThickness(5);
                            
                            
                            
                            pol.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            eraser.setOutlineThickness(5);
                            
                            
                            
                            eraser.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            magenta.setOutlineThickness(5);
                            
                            
                            
                            magenta.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            grey.setOutlineThickness(5);
                            
                            
                            
                            grey.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            
                            
                            
                            
                            red.setOutlineThickness(5);
                            
                            
                            
                            red.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            
                            
                            
                            
                            green.setOutlineThickness(5);
                            
                            
                            
                            green.setOutlineColor(sf::Color(255, 255, 255));
                            
                            text.setOutlineThickness(5);
                             
                            text.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            
                            
                            blue.setOutlineThickness(5);
                            
                            
                            
                            blue.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            
                            
                            
                            
                            yellow.setOutlineThickness(5);
                            
                            
                            
                            yellow.setOutlineColor(sf::Color(30, 80, 530));
                            
                            
                            
                            // if (triclick > 3) {
                            
                            
                            
                            // for (int i = 0; i < tt; i++)
                            
                            
                            
                            t[tt]->_color = "Yellow";
                            
                            
                            
                            
                            
                            
                            
                            //}//
                            
                            
                            
                            //  if ( click > 2) {
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            if (cc - 1 >= 0)
                                
                                c[cc - 1]->_color = "Yellow";
                            
                            
                            
                            // c[cc]._color="Yellow";
                            
                            
                            
                            
                            
                            
                            
                            // }
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            // if (recclick > 4) {
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            if (rr - 1 >= 0)
                                
                                r[rr - 1]->_color = "Yellow";
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            //    }
                            
                            
                            
                            //   if (lineclick > 2) {
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            li[ll]->_color = "Yellow";
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            //  }
                            
                            
                            
                            // if (curve_click > 2) {
                            
                            
                            
                            
                            
                            
                            
                            // for (int i = 0; i < ccurve_count; i++) {
                            
                            
                            
                            
                            
                            
                            
                            c_curve[ccurve_count]->_color = "Yellow";
                            
                            
                            
                            
                            
                            
                            
                            // }
                            
                            
                            
                            
                            
                            
                            
                            //  }
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                        }
                        
                        
                        
                        if (event.mouseButton.x > 30 && event.mouseButton.x <= 80 && event.mouseButton.y > 150 && event.mouseButton.y <= 200)
                            
                            
                            
                        {
                            
                            
                            
                            
                            
                            
                            
                            rectangle.setOutlineThickness(5);
                            
                            
                            
                            rectangle.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            black.setOutlineThickness(5);
                            
                            
                            
                            black.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            circle.setOutlineThickness(5);
                            
                            
                            
                            circle.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            black.setOutlineThickness(5);
                            
                            
                            
                            black.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            text.setOutlineThickness(5);
                             
                            text.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            yellow.setOutlineThickness(5);
                            
                            
                            
                            yellow.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            
                            
                            
                            
                            triangle.setOutlineThickness(5);
                            
                            
                            
                            triangle.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            circle.setOutlineThickness(5);
                            
                            
                            
                            circle.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            line.setOutlineThickness(5);
                            
                            
                            
                            line.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            curve.setOutlineThickness(5);
                            
                            
                            
                            curve.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            
                            
                            
                            
                            pol.setOutlineThickness(5);
                            
                            
                            
                            pol.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            eraser.setOutlineThickness(5);
                            
                            
                            
                            eraser.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            paintbox.setOutlineThickness(5);
                            
                            
                            
                            paintbox.setOutlineColor(sf::Color(255, 255, 255));
                            
                            magenta.setOutlineThickness(5);
                            
                            magenta.setOutlineColor(sf::Color(255, 255, 255));
                            
                            grey.setOutlineThickness(5);
                            
                            grey.setOutlineColor(sf::Color(255, 255, 255));
                            
                            red.setOutlineThickness(5);
                            
                            red.setOutlineColor(sf::Color(255, 255, 255));
                            
                            green.setOutlineThickness(5);
                            
                            green.setOutlineColor(sf::Color(255, 255, 255));
                            
                            blue.setOutlineThickness(5);
                            
                            
                            
                            blue.setOutlineColor(sf::Color(30, 80, 530));
                            t[tt]->_color = "Blue";
                            
                            
                            
                            
                            if (cc - 1 >= 0)
                                
                                c[cc - 1]->_color = "Blue";
                            
                            if (rr - 1 >= 0)
                                
                                r[rr - 1]->_color = "Blue";
                            
                            
                            
                            li[ll]->_color = "Blue";
                            
                            
                            
                            c_curve[ccurve_count]->_color = "Blue";
                            
                            
                            
                        }
                        
                        
                        
                        if (event.mouseButton.x > 30 && event.mouseButton.x <= 80 && event.mouseButton.y > 200 && event.mouseButton.y <= 250)
                            
                            
                            
                        {
                            
                            
                            
                            rectangle.setOutlineThickness(5);
                            
                            
                            
                            rectangle.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            black.setOutlineThickness(5);
                            
                            
                            
                            black.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            circle.setOutlineThickness(5);
                            
                            
                            
                            circle.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            black.setOutlineThickness(5);
                            
                            
                            
                            black.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            
                            
                            
                            
                            yellow.setOutlineThickness(5);
                            
                            
                            
                            yellow.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            blue.setOutlineThickness(5);
                            
                            
                            
                            blue.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            
                            
                            
                            
                            triangle.setOutlineThickness(5);
                            
                            
                            
                            triangle.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            circle.setOutlineThickness(5);
                            
                            
                            
                            circle.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            
                            
                            
                            
                            paintbox.setOutlineThickness(5);
                            
                            
                            
                            paintbox.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            curve.setOutlineThickness(5);
                            
                            
                            
                            curve.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            
                            
                            
                            
                            pol.setOutlineThickness(5);
                            
                            
                            
                            pol.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            magenta.setOutlineThickness(5);
                            
                            
                            
                            magenta.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            grey.setOutlineThickness(5);
                            
                            
                            
                            grey.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            line.setOutlineThickness(5);
                            
                            
                            
                            line.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            text.setOutlineThickness(5);
                             
                            text.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            eraser.setOutlineThickness(5);
                            
                            
                            
                            eraser.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            red.setOutlineThickness(5);
                            
                            
                            
                            red.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            
                            
                            
                            
                            green.setOutlineThickness(5);
                            
                            
                            
                            green.setOutlineColor(sf::Color(30, 80, 530));
                            
                            
                            
                            
                            
                            
                            
                            //  if (triclick > 3) {
                            
                            
                            
                            // for (int i = 0; i < tt; i++)
                            
                            
                            
                            t[tt]->_color = "Green";
                            
                            
                            
                            
                            
                            
                            
                            //}//
                            
                            
                            
                            //if ( click > 2) {
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            if (cc - 1 >= 0)
                                
                                c[cc - 1]->_color = "Green";
                            
                            
                            
                            //c[cc]._color="Green";
                            
                            
                            
                            
                            
                            
                            
                            // }
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            ///if (recclick > 4) {
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            if (rr - 1 >= 0)
                                
                                r[rr - 1]->_color = "Green";
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            //}
                            
                            
                            
                            //if (lineclick > 2) {
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            li[ll]->_color = "Green";
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            //}
                            
                            
                            
                            //if (curve_click > 2) {
                            
                            
                            
                            
                            
                            
                            
                            // for (int i = 0; i < ccurve_count; i++) {
                            
                            
                            
                            
                            
                            
                            
                            c_curve[ccurve_count]->_color = "Green";
                            
                            
                            
                            
                            
                            
                            
                            // }
                            
                            
                            
                            
                            
                            
                            
                            //}
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                        }
                        
                        
                        
                        if (event.mouseButton.x > 30 && event.mouseButton.x <= 80 && event.mouseButton.y > 250 && event.mouseButton.y <= 300)
                            
                            
                            
                        {
                            
                            
                            
                            rectangle.setOutlineThickness(5);
                            
                            
                            
                            rectangle.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            black.setOutlineThickness(5);
                            
                            
                            
                            black.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            circle.setOutlineThickness(5);
                            
                            
                            
                            circle.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            black.setOutlineThickness(5);
                            
                            
                            
                            black.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            
                            
                            
                            
                            yellow.setOutlineThickness(5);
                            
                            
                            
                            yellow.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            blue.setOutlineThickness(5);
                            
                            
                            
                            blue.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            green.setOutlineThickness(5);
                            
                            
                            
                            green.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            
                            text.setOutlineThickness(5);
                             
                            text.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            triangle.setOutlineThickness(5);
                            
                            
                            
                            triangle.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            circle.setOutlineThickness(5);
                            
                            
                            
                            circle.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            curve.setOutlineThickness(5);
                            
                            
                            
                            curve.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            
                            
                            
                            
                            pol.setOutlineThickness(5);
                            
                            
                            
                            pol.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            paintbox.setOutlineThickness(5);
                            
                            
                            
                            paintbox.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            line.setOutlineThickness(5);
                            
                            
                            
                            line.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            
                            
                            
                            
                            eraser.setOutlineThickness(5);
                            
                            
                            
                            eraser.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            magenta.setOutlineThickness(5);
                            
                            
                            
                            magenta.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            grey.setOutlineThickness(5);
                            
                            
                            
                            grey.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            
                            
                            
                            
                            red.setOutlineThickness(5);
                            
                            
                            
                            red.setOutlineColor(sf::Color(30, 80, 530));
                            
                          
                            
                            t[tt]->_color = "Red";
                          
                            
                            //}
                            
                            
                            
                            // if ( click > 2) {
                          
                            if (cc - 1 >= 0)
                                
                                c[cc - 1]->_color = "Red";
                        
                            //c[cc]._color="Red";
                            
                            //}
                           
                            // if (recclick > 4) {
                           
                            if (rr - 1 >= 0)
                                
                                r[rr - 1]->_color = "Red";
                            
                            // }
                            
                            
                            
                            //if (lineclick > 2) {
                           
                            li[ll]->_color = "Red";
                          
                            //}
                            
                            
                            
                            //  if (curve_click > 2) {
                            
                            
                            
                            
                            
                            
                            
                            // for (int i = 0; i < ccurve_count; i++) {
                            
                            
                            
                            
                            
                            
                            
                            c_curve[ccurve_count]->_color = "Red";
                           
                            // }
                          
                            
                            // }
                         
                        }
                        
                        
                        
                        if (event.mouseButton.x > 30 && event.mouseButton.x <= 80 && event.mouseButton.y > 300 && event.mouseButton.y <= 350)
                            
                            
                            
                        {
                            
                            
                            
                            rectangle.setOutlineThickness(5);
                            
                            
                            
                            rectangle.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            black.setOutlineThickness(5);
                            
                            
                            
                            black.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            circle.setOutlineThickness(5);
                            
                            
                            
                            circle.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            black.setOutlineThickness(5);
                            
                            
                            
                            black.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            
                            
                            
                            
                            yellow.setOutlineThickness(5);
                            
                            
                            
                            yellow.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            blue.setOutlineThickness(5);
                            
                            
                            
                            blue.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            green.setOutlineThickness(5);
                            
                            
                            
                            green.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            
                            
                            
                            
                            red.setOutlineThickness(5);
                            
                            
                            
                            red.setOutlineColor(sf::Color(255, 255, 255));
                           
                            triangle.setOutlineThickness(5);
                            
                            
                            
                            triangle.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            circle.setOutlineThickness(5);
                            
                            
                            
                            circle.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            line.setOutlineThickness(5);
                            
                            
                            
                            line.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            curve.setOutlineThickness(5);
                            
                            
                            
                            curve.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            
                            
                            
                            
                            pol.setOutlineThickness(5);
                            
                            
                            
                            pol.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            eraser.setOutlineThickness(5);
                            
                            
                            
                            eraser.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            paintbox.setOutlineThickness(5);
                            
                            
                            
                            paintbox.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            text.setOutlineThickness(5);
                             
                            text.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            
                            magenta.setOutlineThickness(5);
                            
                            
                            
                            magenta.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            grey.setOutlineThickness(5);
                            
                            
                            
                            grey.setOutlineColor(sf::Color(30, 80, 530));
                            
                            
                            
                            // if (triclick > 3) {
                            
                            
                            
                            // for (int i = 0; i < tt; i++)
                            
                            
                            
                            t[tt]->_color = "Grey";
                            
                            
                            
                            
                            
                            
                            
                            //}//
                            
                            
                            
                            //if ( click > 2) {
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            if (cc - 1 >= 0)
                                
                                c[cc - 1]->_color = "Grey";
                            
                            
                            
                            // c[cc]._color="Grey";
                            
                            
                            
                            
                            
                            
                            
                            // }
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            //if (recclick > 4) {
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            if (rr - 1 >= 0)
                                
                                r[rr - 1]->_color = "Grey";
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            //}
                            
                            
                            
                            //if (lineclick > 2) {
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            li[ll]->_color = "Grey";
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            //}
                            
                            
                            
                            //if (curve_click > 2) {
                            
                            
                            
                            
                            
                            
                            
                            // for (int i = 0; i < ccurve_count; i++) {
                            
                            
                            
                            
                            
                            
                            
                            c_curve[ccurve_count]->_color = "Grey";
                            
                            
                            
                            
                            
                            
                            
                            // }
                            
                            
                            
                            
                            
                            
                            
                            //}
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                        }
                        
                        
                        
                        if (event.mouseButton.x > 30 && event.mouseButton.x <= 80 && event.mouseButton.y > 350 && event.mouseButton.y <= 400)
                            
                            
                            
                        {
                          //  pressed=false ;
                           // recpressed=false ;
                           // tripressed=false ;
                            
                            
                            rectangle.setOutlineThickness(5);
                            
                            
                            
                            rectangle.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            black.setOutlineThickness(5);
                            
                            
                            
                            black.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            circle.setOutlineThickness(5);
                            
                            
                            
                            circle.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            black.setOutlineThickness(5);
                            
                            
                            
                            black.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            
                            
                            
                            
                            yellow.setOutlineThickness(5);
                            
                            
                            
                            yellow.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            blue.setOutlineThickness(5);
                            
                            
                            
                            blue.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            green.setOutlineThickness(5);
                            
                            
                            
                            green.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            curve.setOutlineThickness(5);
                            
                            
                            
                            curve.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            text.setOutlineThickness(5);
                             
                            text.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            pol.setOutlineThickness(5);
                            
                            
                            
                            pol.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            red.setOutlineThickness(5);
                            
                            
                            
                            red.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            grey.setOutlineThickness(5);
                            
                            
                            
                            grey.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            triangle.setOutlineThickness(5);
                            
                            
                            
                            triangle.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            circle.setOutlineThickness(5);
                            
                            
                            
                            circle.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            line.setOutlineThickness(5);
                            
                            
                            
                            line.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            
                            
                            
                            
                            eraser.setOutlineThickness(5);
                            
                            
                            
                            eraser.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            paintbox.setOutlineThickness(5);
                            
                            
                            
                            paintbox.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            
                            
                            
                            
                            magenta.setOutlineThickness(5);
                            
                            
                            
                            magenta.setOutlineColor(sf::Color(30, 80, 530));
                            
                            
                            
                            
                            
                            
                            
                            // if (triclick > 3) {
                            
                            
                            
                            // for (int i = 0; i < tt; i++)
                            
                            
                            
                            t[tt]->_color = "Magenta";
                            
                            
                            
                            
                            
                            
                            
                            //}//
                            
                            
                            
                            //if ( click > 2) {
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            if (cc - 1 >= 0)
                                
                                c[cc - 1]->_color = "Magenta";
                            
                            
                            
                            // c[cc]._color="Magenta";
                            
                            
                            
                            
                            
                            
                            
                            // }
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            ///if (recclick > 4) {
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            if (rr - 1 >= 0)
                                
                                r[rr - 1]->_color = "Magenta";
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            //}
                            
                            
                            
                            //if (lineclick > 2) {
                            
                            li[ll]->_color = "Magenta";
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            //}
                            
                            
                            
                            //if (curve_click > 2) {
                            
                            
                            
                            
                            
                            
                            
                            // for (int i = 0; i < ccurve_count; i++) {
                            
                            
                            
                            
                            
                            
                            
                            c_curve[ccurve_count]->_color = "Magenta";
                            
                            
                            
                            
                            
                            
                            
                            // }
                            
                            
                            
                            
                            
                            
                            
                            //}
                            
                            
                            
                        }
                        
                        
                        
                        
                        
                        
                        
                        if (event.mouseButton.x > 30 && event.mouseButton.x <= 80 && event.mouseButton.y > 450 && event.mouseButton.y <= 500)
                            
                            
                            
                        {
                            
                            
                            
                            paint_pressed = true;
                            
                            
                            
                            linepressed = false;
                            
                            
                            
                            recpressed = false;
                            
                            
                            
                            tripressed = false;
                            
                            
                            
                            pressed = false;
                            
                            
                            
                            curve_press = false;
                            
                            
                            
                            black_pressed = false;
                            
                            
                            
                            rectangle.setOutlineThickness(5);
                            
                            
                            
                            rectangle.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            black.setOutlineThickness(5);
                            
                            
                            
                            black.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            circle.setOutlineThickness(5);
                            
                            
                            
                            circle.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            black.setOutlineThickness(5);
                            
                            
                            
                            black.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            
                            
                            
                            
                            yellow.setOutlineThickness(5);
                            
                            
                            
                            yellow.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            blue.setOutlineThickness(5);
                            
                            
                            
                            blue.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            green.setOutlineThickness(5);
                            
                            
                            
                            green.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            curve.setOutlineThickness(5);
                            
                            
                            
                            curve.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            
                            
                            
                            
                            pol.setOutlineThickness(5);
                            
                            
                            
                            pol.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            red.setOutlineThickness(5);
                            
                            
                            
                            red.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            grey.setOutlineThickness(5);
                            
                            
                            
                            grey.setOutlineColor(sf::Color(255, 255, 255));
                            
                            text.setOutlineThickness(5);
                             
                            text.setOutlineColor(sf::Color(255, 255, 255));
                            
                            line.setOutlineThickness(5);
                            
                            
                            
                            line.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            
                            
                            
                            
                            eraser.setOutlineThickness(5);
                            
                            
                            
                            eraser.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            magenta.setOutlineThickness(5);
                            
                            
                            
                            magenta.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            triangle.setOutlineThickness(5);
                            
                            
                            
                            triangle.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            circle.setOutlineThickness(5);
                            
                            
                            
                            circle.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            
                            
                            
                            
                            paintbox.setOutlineThickness(5);
                            
                            
                            
                            paintbox.setOutlineColor(sf::Color(30, 80, 530));
                            
                            
                            
                            break;
                            
                            
                            
                        }
                        
                        if (rr - 1 >= 0) {
                            
                            if (paint_pressed == true && pressed == false)
                                
                            {
                                
                                int i, j;
                                
                                i = event.mouseButton.x;
                                
                                j = event.mouseButton.y;
                                
                                
                                
                                if (j >= rectangle_points[0][1] && j <= rectangle_points[1][1]) {
                                    
                                    
                                    
                                    if (i >= rectangle_points[0][0] && i <= rectangle_points[1][0]) {
                                        
                                        cout << "inside rectangle " << endl;
                                        
                                        rectangle_clr[rr - 1] = 1;
                                        
                                    }
                                    
                                }
                                
                                else
                                    
                                {
                                    
                                    cout << "outside rectangle " << endl;
                                    
                                    rectangle_clr[rr - 1] = 0;
                                    
                                }
                                
                            }
                            
                        }
                        
                        if (cc - 1 >= 0)
                            
                        {
                            
                            if (paint_pressed == true && recpressed == false)
                                
                                
                                
                            {
                                
                                
                                
                                int** check_circleee = c[cc - 1]->get_points();
                                
                                
                                
                                cout << c[cc - 1]->get_points()[0][0] << "-------checkkkkkk----" << endl;
                                
                                
                                
                                
                                
                                
                                
                                int radiuss = sqrt(pow((c[cc - 1]->get_points()[0][0] - c[cc - 1]->get_points()[1][0]), 2) +
                                                   pow(c[cc - 1]->get_points()[0][1] - c[cc - 1]->get_points()[1][1], 2) * 1.0);
                                
                                
                                
                                int d = pow(radiuss, 2) - (pow((c[cc - 1]->get_points()[0][0] - c[cc - 1]->get_points()[1][0]), 2) + pow((c[cc - 1]->get_points()[0][1] - c[cc - 1]->get_points()[1][1]), 2));
                                
                                
                                
                                cout << "======= D ===========" << d << endl;
                                
                                
                                
                                if (d < 0) {
                                  //  pressed=true ;
                                    circle_clr[cc - 1] = 1;
                                    cout << "------" << cc - 1 << "-----" << endl;
                                    cout << "inside circle " << endl;
                                    
                                }
                                
                                else if (d == 0) {
                                  //  pressed=true ;
                                    circle_clr[cc - 1] = 1;
                                    
                                    
                                    
                                    cout << "on circumference" << endl;
                                    
                                }
                                
                                else {
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    circle_clr[cc - 1] = 0;
                                    
                                    
                                    
                                    cout << "outside circle " << endl;
                                    
                                }
                            }
                            
                            
                            
                        }
                        
                        if (event.mouseButton.x > 30 && event.mouseButton.x <= 80 && event.mouseButton.y > 610 && event.mouseButton.y <= 660)
                        {
                            tripressed = true;
                            
                            pressed = false;
                            
                            
                            
                            recpressed = false;
                            
                            
                            
                            rectangle.setOutlineThickness(5);
                            
                            
                            
                            rectangle.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            yellow.setOutlineThickness(5);
                            
                            
                            
                            yellow.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            blue.setOutlineThickness(5);
                            
                            
                            
                            blue.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            green.setOutlineThickness(5);
                            
                            
                            
                            green.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            curve.setOutlineThickness(5);
                            
                            
                            
                            curve.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            text.setOutlineThickness(5);
                             
                            text.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            
                            pol.setOutlineThickness(5);
                            
                            
                            
                            pol.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            red.setOutlineThickness(5);
                            
                            
                            
                            red.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            grey.setOutlineThickness(5);
                            
                            
                            
                            grey.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            line.setOutlineThickness(5);
                            
                            
                            
                            line.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            
                            
                            
                            
                            eraser.setOutlineThickness(5);
                            
                            
                            
                            eraser.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            magenta.setOutlineThickness(5);
                            
                            
                            
                            magenta.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            
                            
                            
                            
                            /*rectangle.setOutlineThickness(5);
                             
                             
                             
                             rectangle.setOutlineColor(sf::Color(255, 255, 255));*/
                            
                            
                            
                            
                            
                            
                            
                            paintbox.setOutlineThickness(5);
                            
                            
                            
                            paintbox.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            black.setOutlineThickness(5);
                            
                            
                            
                            black.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            circle.setOutlineThickness(5);
                            
                            
                            
                            circle.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            triangle.setOutlineThickness(5);
                            
                            
                            
                            triangle.setOutlineColor(sf::Color(30, 80, 530));
                            
                            
                            
                            //cout << "click tri" << endl;
                            
                            
                            
                            break;
                            
                            
                            
                        }
                        
                        if (tripressed == true && pressed == false && event.mouseButton.x > 80)
                        {
                            
                            if (triclick > 3) {
                                
                                triclick = 0;
                                
                                
                                
                            }
                            
                            if (triclick == 0)
                                
                                
                                
                            {
                                
                                
                                
                                triangle_points[0][0] = event.mouseButton.x;
                                
                                
                                
                                triangle_points[0][1] = event.mouseButton.y;
                                
                                
                                
                                //cout << "-------------1------------";
                                
                                
                                
                            }
                            
                            if (triclick == 1)
                            {
                                triangle_points[1][0] = event.mouseButton.x;
                                triangle_points[1][1] = event.mouseButton.y;
                                // cout << tx2 << " " << ty2 << endl;
                                // cout << "-------------2------------";
                            }
                            
                            if (triclick == 2)
                            {
                                triangle_points[2][0] = event.mouseButton.x;
                                
                                triangle_points[2][1] = event.mouseButton.y;
                                //cout << tx3 << " " << ty3 << endl;
                            }
                            
                            
                            triclick++;
                            if (triclick == 3)
                            {
                                
                                
                                
                                // cout << "-------------check--------------";
                                
                                
                                
                                t[tt]->set_no_of_points(3);
                                
                                
                                
                                t[tt]->contains(triangle_points);
                                
                                
                                
                                
                                
                                
                                
                                tt++;
                                
                                
                                
                            }
                            
                            
                            
                        }
                        
                        
                        
                        if (event.mouseButton.x > 30 && event.mouseButton.x <= 80 && event.mouseButton.y > 530 && event.mouseButton.y <= 580)
                        {
                            
                            
                            
                            recpressed = false;
                            
                            
                            
                            pressed = true;
                            
                            
                            
                            triclick = false;
                            
                            eraserpressed=false ;
                            
                            linepressed = false;
                            
                            
                            
                            black_pressed = false;
                            
                            
                            
                            rectangle.setOutlineThickness(5);
                            
                            
                            
                            rectangle.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            yellow.setOutlineThickness(5);
                            
                            
                            
                            yellow.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            blue.setOutlineThickness(5);
                            
                            
                            
                            blue.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            green.setOutlineThickness(5);
                            
                            
                            
                            green.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            
                            
                            
                            
                            red.setOutlineThickness(5);
                            
                            
                            
                            red.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            grey.setOutlineThickness(5);
                            
                            
                            
                            grey.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            
                            
                            
                            
                            magenta.setOutlineThickness(5);
                            
                            
                            
                            magenta.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            line.setOutlineThickness(5);
                            
                            
                            
                            line.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            curve.setOutlineThickness(5);
                            
                            
                            
                            curve.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            
                            
                            
                            
                            pol.setOutlineThickness(5);
                            
                            
                            
                            pol.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            eraser.setOutlineThickness(5);
                            
                            
                            
                            eraser.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            paintbox.setOutlineThickness(5);
                            
                            
                            
                            paintbox.setOutlineColor(sf::Color(255, 255, 255));
                            
                            text.setOutlineThickness(5);
                             
                            text.setOutlineColor(sf::Color(255, 255, 255));
                            
                            black.setOutlineThickness(5);
                            
                            
                            
                            black.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            triangle.setOutlineThickness(5);
                            
                            
                            
                            triangle.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            circle.setOutlineThickness(5);
                            
                            
                            
                            circle.setOutlineColor(sf::Color(30, 80, 530));
                            
                            
                            
                            //cout << "clicked" << endl;
                            
                            
                            
                            break;
                            
                            
                            
                            
                            
                            
                            
                        }
                        
                        
                        
                        if (pressed == true && triclick == false && black_pressed == false && event.mouseButton.x > 80)
                            
                            
                            
                        {
                            recpressed=false ;
                            
                            
                            if (click > 2)
                                
                            {
                                
                                
                                
                                click = 0;
                                
                                
                                
                            }
                            
                            
                            
                            if (click == 0)
                                
                                
                                
                            {
                                
                                
                                
                                circle_points[0] = new int[2];
                                
                                
                                
                                x = event.mouseButton.x;
                                
                                
                                
                                y = event.mouseButton.y;
                                
                                
                                
                                circle_points[0][0] = x;
                                
                                
                                
                                circle_points[0][1] = y;
                                
                                
                                
                                check_circle[cc_count][0] = x;
                                
                                
                                
                                check_circle[cc_count][1] = y;
                                
                                
                                
                                cc_count++;
                                
                                
                                
                            }
                            
                            
                            
                            cout << x << " " << y << endl;
                            
                            
                            
                            if (click == 1)
                                
                                
                                
                            {
                                
                                
                                
                                circle_points[1] = new int[2];
                                
                                
                                
                                
                                
                                
                                
                                X = event.mouseButton.x;
                                
                                
                                
                                Y = event.mouseButton.y;
                                
                                
                                
                                circle_points[1][0] = X;
                                
                                
                                
                                circle_points[1][1] = Y;
                                
                                
                                
                                check_circle[cc_count][0] = X;
                                
                                
                                
                                check_circle[cc_count][1] = Y;
                                
                                
                                
                                cc_count++;
                                
                                
                                
                                cout << X << " " << Y << endl;
                                
                                
                                
                            }
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            click++;
                            
                            
                            
                            if (click >= 2)
                                
                                
                                
                            {
                                
                                
                                
                                
                                
                                
                                
                                c[cc]->set_no_of_points(2);
                                
                                
                                
                                c[cc]->set_points(circle_points);
                                
                                
                                
                                c[cc]->contains(circle_points);
                                
                                
                                
                                cc++;
                                
                                
                                
                                break;
                                
                                
                                
                                
                                
                                
                                
                            }
                            
                            
                            
                            
                            
                            
                            
                        }
                        
                        
                        if (event.mouseButton.x > 30 && event.mouseButton.x <= 80 && event.mouseButton.y > 690 && event.mouseButton.y <= 740)
                            
                            
                            
                        {
                            
                            
                            
                            //Rectangle
                            
                            
                            
                            
                            
                            
                            
                            recpressed = true;
                            
                            
                            
                            pressed = false;
                            
                            
                            
                            tripressed = false;
                            eraserpressed=false ;
                            
                            
                            yellow.setOutlineThickness(5);
                            
                            
                            
                            yellow.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            blue.setOutlineThickness(5);
                            
                            
                            
                            blue.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            green.setOutlineThickness(5);
                            
                            
                            
                            green.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            
                            
                            
                            
                            red.setOutlineThickness(5);
                            
                            
                            
                            red.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            grey.setOutlineThickness(5);
                            
                            
                            
                            grey.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            
                            
                            
                            
                            magenta.setOutlineThickness(5);
                            
                            
                            
                            magenta.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            line.setOutlineThickness(5);
                            
                            
                            
                            line.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            curve.setOutlineThickness(5);
                            
                            
                            
                            curve.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            
                            
                            
                            
                            pol.setOutlineThickness(5);
                            
                            
                            
                            pol.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            eraser.setOutlineThickness(5);
                            
                            
                            
                            eraser.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            paintbox.setOutlineThickness(5);
                            
                            
                            
                            paintbox.setOutlineColor(sf::Color(255, 255, 255));
                            
                            text.setOutlineThickness(5);
                             
                            text.setOutlineColor(sf::Color(255, 255, 255));
                            
                            black.setOutlineThickness(5);
                            
                            
                            
                            black.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            circle.setOutlineThickness(5);
                            
                            
                            
                            circle.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            triangle.setOutlineThickness(5);
                            
                            
                            
                            triangle.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            
                            
                            
                            
                            rectangle.setOutlineThickness(5);
                            
                            
                            
                            rectangle.setOutlineColor(sf::Color(30, 80, 530));
                            
                            
                            
                            break;
                            
                            
                            
                        }
                        
                        
                        
                        if (recpressed == true && tripressed != true && pressed != true && event.mouseButton.x > 80)
                            
                            
                            
                        {
                            
                            if (recclick > 2) {
                                
                                
                                
                                recclick = 0;
                                
                                
                                
                            }
                            
                            
                            
                            if (recclick == 0)
                                
                                
                                
                            {
                                
                                
                                
                                rectangle_points[0][0] = event.mouseButton.x;
                                
                                
                                
                                rectangle_points[0][1] = event.mouseButton.y;
                                
                                
                                
                                
                                
                                
                                
                                cout << "rx1--------------" << rectangle_points[0][0] << endl;
                                
                                
                                
                            }
                            
                            
                            
                            // cout << rx1 << " " << ry1 << endl;
                            
                            
                            
                            if (recclick == 1)
                                
                                
                                
                            {
                                
                                
                                
                                rectangle_points[1][0] = event.mouseButton.x;
                                
                                
                                
                                rectangle_points[1][1] = event.mouseButton.y;
                                
                                
                                
                                //cout << rx2 << " " << ry2 << endl;
                                
                                
                                
                            }
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            recclick++;
                            
                            
                            
                            if (recclick == 2)
                                
                                
                                
                            {
                                
                                
                                
                                cout << "================check=================" << endl;
                                
                                
                                
                                r[rr]->set_no_of_points(4);
                                
                                
                                
                                r[rr]->contains(rectangle_points);
                                
                                
                                
                                rr++;
                                
                                
                                
                            }
                            
                            
                            
                        }
                        
                        
                        
                        
                        
                        
                        
                        if (event.mouseButton.x > 30 && event.mouseButton.x <= 80 && event.mouseButton.y > 770 && event.mouseButton.y <= 820)
                            
                            
                            
                        {
                            
                            
                            
                            //line
                            
                            
                            
                            linepressed = true;
                            
                            
                            
                            recpressed = false;
                            
                            
                            
                            tripressed = false;
                            
                            
                            
                            pressed = false;
                            
                            eraserpressed=false ;
                            
                            curve_press = false;
                            
                            
                            
                            yellow.setOutlineThickness(5);
                            
                            
                            
                            yellow.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            blue.setOutlineThickness(5);
                            
                            
                            
                            blue.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            green.setOutlineThickness(5);
                            
                            
                            
                            green.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            
                            
                            
                            
                            red.setOutlineThickness(5);
                            
                            
                            
                            red.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            grey.setOutlineThickness(5);
                            
                            
                            
                            grey.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            
                            
                            
                            
                            magenta.setOutlineThickness(5);
                            
                            
                            
                            magenta.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            curve.setOutlineThickness(5);
                            
                            
                            
                            curve.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            
                            
                            
                            
                            pol.setOutlineThickness(5);
                            
                            
                            
                            pol.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            paintbox.setOutlineThickness(5);
                            
                            
                            
                            paintbox.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            black.setOutlineThickness(5);
                            
                            
                            
                            black.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            circle.setOutlineThickness(5);
                            
                            
                            
                            circle.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            triangle.setOutlineThickness(5);
                            
                            
                            
                            triangle.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            
                            text.setOutlineThickness(5);
                             
                            text.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            rectangle.setOutlineThickness(5);
                            
                            
                            
                            rectangle.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            
                            
                            
                            
                            eraser.setOutlineThickness(5);
                            
                            
                            
                            eraser.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            line.setOutlineThickness(5);
                            
                            
                            
                            line.setOutlineColor(sf::Color(30, 80, 530));
                            
                            
                            
                            break;
                            
                            
                            
                        }
                        
                        
                        
                        if (linepressed == true && tripressed != true && pressed != true && recpressed != true && event.mouseButton.x > 80)
                            
                            
                            
                        {
                          
                            if (lineclick > 2) {
                                
                                
                                lineclick = 0;
                                
                            }
                            
                         
                            if (lineclick == 0)
                                
                            {
                               
                                line_points[0][0] = event.mouseButton.x;
                                
                                
                                
                                line_points[0][1] = event.mouseButton.y;
                               
                                cout << "rx1--------------" << line_points[0][0] << endl;
                                
                                
                                
                            }
                            
                            
                            
                            // cout << rx1 << " " << ry1 << endl;
                            
                            
                            
                            if (lineclick == 1)
                                
                                
                                
                            {
                                
                                
                                
                                line_points[1][0] = event.mouseButton.x;
                                
                                
                                
                                line_points[1][1] = event.mouseButton.y;
                                
                                
                                
                                //cout << rx2 << " " << ry2 << endl;
                                
                                
                                
                            }
                          
                            lineclick++;
                          
                            if (lineclick == 2)
                                
                            {
                               
                                cout << "================check=================" << endl;
                                
                                li[ll]->set_no_of_points(2);
                                
                                li[ll]->contains(line_points);
                                
                                ll++;
                                
                                
                                
                            }
                            
                        }
                        
                        if (event.mouseButton.x > 30 && event.mouseButton.x <= 80 && event.mouseButton.y > 850 && event.mouseButton.y <= 900)
                            
                        {
                           
                            //eraser
                           
                            eraserpressed = true;
                           
                            linepressed = false;  tripressed = false; pressed = false; recpressed = false;
                            
                            yellow.setOutlineThickness(5);
                            
                            
                            
                            yellow.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            blue.setOutlineThickness(5);
                            
                            
                            
                            blue.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            green.setOutlineThickness(5);
                            
                            
                            
                            green.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            
                            
                            
                            
                            red.setOutlineThickness(5);
                            
                            
                            
                            red.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            grey.setOutlineThickness(5);
                            
                            
                            
                            grey.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            
                            
                            
                            
                            magenta.setOutlineThickness(5);
                            
                            
                            
                            magenta.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            curve.setOutlineThickness(5);
                            
                            
                            
                            curve.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            
                            
                            
                            
                            pol.setOutlineThickness(5);
                            
                            
                            
                            pol.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            paintbox.setOutlineThickness(5);
                            
                            
                            
                            paintbox.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            black.setOutlineThickness(5);
                            
                            
                            
                            black.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            circle.setOutlineThickness(5);
                            
                            
                            
                            circle.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            triangle.setOutlineThickness(5);
                            
                            
                            
                            triangle.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            text.setOutlineThickness(5);
                             
                            text.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            rectangle.setOutlineThickness(5);
                            
                            
                            
                            rectangle.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            
                            
                            
                            
                            line.setOutlineThickness(5);
                            
                            
                            
                            line.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            
                            
                            
                            
                            eraser.setOutlineThickness(5);
                            
                            
                            
                            eraser.setOutlineColor(sf::Color(30, 80, 530));
                            
                            
                            
                            break;
                            
                            
                            
                        }
                        
                        
                        
                     //   int max_x, min_x, max_y, min_y;
                        
                        
                        
                        if (eraserpressed == true && linepressed != true && tripressed != true && pressed != true && recpressed != true && event.mouseButton.x > 80)
                            
                        {
                            
                            
                            if (eraseclick == 0)
                                
                            {
                                
                                ex = event.mouseButton.x;
                                
                                ey = event.mouseButton.y;
                                
                                cout << "fatima" << ex << " " << ey << endl;
                            }
                            
                            
                            
                            eraseclick++;
                            int** rectangllle_points;
                            if (eraserpressed == true) {
                                int ii = event.mouseButton.x;
                                
                                int jj = event.mouseButton.y;
                                
                                for (int i = 0; i < rr; i++) {
                                    if(r[i]!=nullptr){
                                        rectangllle_points = r[i]->get_points();
                                        
                                        if (eraserpressed == true) {
                                            if (jj >= rectangllle_points[0][1] && jj <= rectangllle_points[1][1]) {
                                                
                                                
                                                
                                                if (ii >= rectangllle_points[0][0] && ii <= rectangllle_points[1][0]) {
                                                    
                                                    cout << "inside rectangle(erase) " << endl;
                                                    if(r[i]!=nullptr)
                                                        r[i]->_color="White" ;
                                                    r[i]->draw();
                                                    r[i]->fill(2);
                                                    break;
                                            
                                                    //rectangle_clr[rr - 1] = 1;
                                                }
                                            }
                                            
                                        }
                                    }
                                    //  int i = 0;
                                }
                                for (int i = 0; i < cc; i++) {
                                    int** circllle_points = c[i]->get_points();
                                    // for (int i = 0; i < 2000; i++)
                                    //{
                                    //  for (int j = 0; j < 1400; j++)
                                    //{
                                    int rrrradius = sqrt(pow(circllle_points[0][0] - circllle_points[1][0], 2) + pow(circllle_points[0][1] - circllle_points[1][1], 2 * 1.0));
                                    
                                    
                                    int d = pow(rrrradius, 2) - (pow((c[i]->get_points()[0][0] - c[i]->get_points()[1][0]), 2) + pow((c[i]->get_points()[0][1] - c[i]->get_points()[1][1]), 2));
                                    
                                    
                                    
                                    cout << "======= D ===========" << d << endl;
                                    
                                    
                                    
                                    if (d < 0) {
                                        
                                        
                                        //shade.append(pixel);
                                        if(c[i]!=nullptr)
                                        {
                                            c[i]->_color="White";
                                            cout<<"erase check "<<endl;
                                            c[i]->draw();
                                            c[i]->fill(2);
                                        }
                                        
                                        cout << "inside circle " << endl;
                                        
                                    }
                                    
                                    else if (d == 0) {
                                        
                                        if(c[i]!=nullptr)
                                        {
                                            c[i]->_color="White";
                                            cout<<"erase check "<<endl;
                                            c[i]->draw();
                                            c[i]->fill(2);
                                        }
                                        
                                        
                                        
                                        cout << "on circumference" << endl;
                                        
                                    }
                                    
                                    else {
                                        
                                        cout << "outside circle " << endl;
                                        
                                        
                                        
                                    }
                                    
                                    
                                }
                                
                                //    }
                                //  }
                                
                                /*     for (; i < cc_count; i++) {
                                 
                                 
                                 
                                 x_circle = circle_points[1][0] - circle_points[0][0];
                                 
                                 
                                 
                                 if (x_circle < 0)
                                 
                                 
                                 
                                 {
                                 
                                 
                                 
                                 x_circle *= -1;
                                 
                                 
                                 
                                 }
                                 
                                 
                                 
                                 y_circle = circle_points[1][1] - circle_points[0][1];
                                 
                                 
                                 
                                 if (y_circle < 0)
                                 
                                 
                                 
                                 {
                                 
                                 
                                 
                                 y_circle *= -1;
                                 
                                 
                                 
                                 }
                                 
                                 
                                 
                                 int cond1_x = circle_points[0][0] + x_circle;
                                 
                                 
                                 
                                 int cond2_x = circle_points[0][0] - x_circle;
                                 
                                 
                                 
                                 
                                 
                                 
                                 
                                 int cond1_y = circle_points[0][1] + y_circle;
                                 
                                 
                                 
                                 int cond2_y = circle_points[0][1] - y_circle;
                                 
                                 
                                 
                                 
                                 
                                 
                                 
                                 if (cond1_x > cond2_x)
                                 
                                 
                                 
                                 {
                                 
                                 
                                 
                                 max_x = cond1_x;
                                 
                                 
                                 
                                 min_x = cond2_x;
                                 
                                 
                                 
                                 }
                                 
                                 
                                 
                                 else
                                 
                                 
                                 
                                 {
                                 
                                 
                                 
                                 max_x = cond2_x;
                                 
                                 
                                 
                                 min_x = cond1_x;
                                 
                                 
                                 
                                 }
                                 
                                 
                                 
                                 if (cond1_y > cond2_y)
                                 
                                 
                                 
                                 {
                                 
                                 
                                 
                                 max_y = cond1_y;
                                 
                                 
                                 
                                 min_y = cond2_y;
                                 
                                 
                                 
                                 }
                                 
                                 
                                 
                                 else
                                 
                                 
                                 
                                 {
                                 
                                 
                                 
                                 max_y = cond2_y;
                                 
                                 
                                 
                                 min_y = cond1_y;
                                 
                                 
                                 
                                 }
                                 
                                 
                                 
                                 cout << max_x << " " << min_x << " " << max_y << " " << min_y << " " << endl;
                                 
                                 
                                 
                                 if (ex > min_x && ex<max_x && ey>min_y && ey < max_y)
                                 
                                 
                                 
                                 {
                                 
                                 
                                 
                                 c_check = true;
                                 
                                 
                                 
                                 break;
                                 
                                 
                                 
                                 // std::cout << "sub" << radius << endl
                                 
                                 
                                 
                                 }
                                 
                                 
                                 
                                 }
                                 
                                 
                                 */
                                /*if (c_check == true)
                                 
                                 
                                 
                                 {
                                 
                                 
                                 
                                 c_radius = sqrt(pow(check_circle[i][0] - check_circle[i + 1][0], 2) +
                                 
                                 
                                 
                                 
                                 
                                 
                                 
                                 pow(check_circle[i][1] - check_circle[i + 1][1], 2) * 1.0);
                                 
                                 
                                 
                                 cout << "check" << check_circle[i][0];
                                 
                                 
                                 
                                 cout << "check" << check_circle[i][1];
                                 
                                 
                                 
                                 shape1.setRadius(c_radius);
                                 
                                 
                                 
                                 shape1.setOutlineThickness(4);
                                 
                                 
                                 
                                 shape1.setOutlineColor(sf::Color(255, 255, 255));
                                 
                                 
                                 
                                 shape1.setPosition(check_circle[i][0], check_circle[i][1]);
                                 
                                 
                                 
                                 shape1.setOrigin(c_radius, c_radius);
                                 
                                 
                                 
                                 
                                 
                                 
                                 
                                 }
                                 */
                            }
                        }
                        if (event.mouseButton.x > 30 && event.mouseButton.x <= 80 && event.mouseButton.y > 930 && event.mouseButton.y <= 980)
                            
                            
                            
                        {
                            
                            
                            
                            cout << "curve===========" << endl;
                            
                            
                            
                            linepressed = false;
                            
                            
                            
                            recpressed = false;
                            
                            
                            
                            tripressed = false;
                            
                            
                            
                            pressed = false;
                            
                            
                            
                            curve_press = true;
                            
                            
                            
                            yellow.setOutlineThickness(5);
                            
                            
                            
                            yellow.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            blue.setOutlineThickness(5);
                            
                            
                            
                            blue.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            green.setOutlineThickness(5);
                            
                            
                            
                            green.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            
                            
                            
                            
                            red.setOutlineThickness(5);
                            
                            
                            
                            red.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            grey.setOutlineThickness(5);
                            
                            
                            
                            grey.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            
                            
                            
                            
                            magenta.setOutlineThickness(5);
                            
                            
                            
                            magenta.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            
                            
                            
                            
                            paintbox.setOutlineThickness(5);
                            
                            
                            
                            paintbox.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            black.setOutlineThickness(5);
                            
                            
                            
                            black.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            circle.setOutlineThickness(5);
                            
                            
                            
                            circle.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            triangle.setOutlineThickness(5);
                            
                            
                            
                            triangle.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            
                            
                            
                            
                            rectangle.setOutlineThickness(5);
                            
                            
                            
                            rectangle.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            
                            
                            
                            
                            line.setOutlineThickness(5);
                            
                            
                            
                            line.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            
                            
                            
                            
                            eraser.setOutlineThickness(5);
                            
                            
                            
                            eraser.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            text.setOutlineThickness(5);
                             
                            text.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            
                            pol.setOutlineThickness(5);
                            
                            
                            
                            pol.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            
                            
                            
                            
                            curve.setOutlineThickness(5);
                            
                            
                            
                            curve.setOutlineColor(sf::Color(30, 80, 530));
                            
                            
                            
                            break;
                            
                            
                            
                        }
                        
                        
                        
                        if (curve_press == true && pressed == false && triclick == false && linepressed != true && event.mouseButton.x > 80)
                            
                            
                            
                        {
                            
                            
                            
                            cout << "fatima" << endl;
                            
                            
                            
                            if (curve_click > 2)
                                
                                
                                
                            {
                                
                                
                                
                                curve_click = 0;
                                
                                
                                
                            }
                            
                            
                            
                            if (curve_click == 0)
                                
                                
                                
                            {
                                
                                
                                
                                curve_points[0] = new int[2];
                                
                                
                                
                                curve_points[0][0] = event.mouseButton.x;
                                
                                
                                
                                curve_points[0][1] = event.mouseButton.y;
                                
                                
                                
                                //curve_points[0][0] = x;
                                
                                
                                
                                // curve_points[0][1] = y;
                                
                                
                                
                                curve_points[ccurve_count][0] = curve_points[0][0];
                                
                                
                                
                                curve_points[ccurve_count][1] = curve_points[0][1];
                                
                                
                                
                                ccurve_count++;
                                
                                
                                
                            }
                            
                            
                            
                            cout << curve_points[0][0] << " " << curve_points[0][1] << endl;
                            
                            
                            
                            if (curve_click == 1)
                                
                                
                                
                            {
                                
                                
                                
                                curve_points[1] = new int[2];
                                
                                
                                
                                int x_c, y_c = 0;
                                
                                
                                
                                x_c = event.mouseButton.x;
                                
                                
                                
                                y_c = event.mouseButton.y;
                                
                                
                                
                                curve_points[1][0] = x_c;
                                
                                
                                
                                curve_points[1][1] = y_c;
                                
                                
                                
                                check_curve[ccurve_count][0] = x_c;
                                
                                
                                
                                check_curve[ccurve_count][1] = y_c;
                                
                                
                                
                                ccurve_count++;
                                
                                
                                
                                cout << x_c << " " << y_c << endl;
                                
                            }
                            
                            
                            
                            
                            
                            
                            
                            curve_click++;
                            
                            
                            
                            if (curve_click >= 2)
                                
                                
                                
                            {
                                
                                
                                
                                
                                
                                
                                
                                c_curve[cc_curve]->set_no_of_points(2);
                                
                                
                                
                                c_curve[cc_curve]->set_points(curve_points);
                                
                                
                                
                                c_curve[cc_curve]->contains(curve_points);
                                
                                
                                
                                cc_curve++;
                                
                                
                                
                                break;
                                
                                
                                
                                
                                
                                
                                
                            }
                            
                            
                            
                        }
                        
                        
                        
                        if (event.mouseButton.x > 30 && event.mouseButton.x <= 80 && event.mouseButton.y > 1020 && event.mouseButton.y <= 1080)
                            
                            
                            
                        {
                            
                            
                            
                            linepressed = false;
                            
                            
                            
                            recpressed = false;
                            
                            
                            
                            tripressed = false;
                            
                            
                            
                            pressed = false;
                            
                            
                            
                            curve_press = false;
                            
                            
                            
                            poly_press = true;
                            
                            
                            
                            yellow.setOutlineThickness(5);
                            
                            
                            
                            yellow.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            blue.setOutlineThickness(5);
                            
                            
                            
                            blue.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            green.setOutlineThickness(5);
                            
                            
                            
                            green.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            
                            
                            
                            
                            red.setOutlineThickness(5);
                            
                            
                            
                            red.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            grey.setOutlineThickness(5);
                            
                            
                            
                            grey.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            
                            
                            
                            
                            magenta.setOutlineThickness(5);
                            
                            
                            
                            magenta.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            
                            
                            
                            
                            paintbox.setOutlineThickness(5);
                            
                            
                            
                            paintbox.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            black.setOutlineThickness(5);
                            
                            
                            
                            black.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            circle.setOutlineThickness(5);
                            
                            
                            
                            circle.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            triangle.setOutlineThickness(5);
                            
                            
                            
                            triangle.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            
                            
                            
                            
                            rectangle.setOutlineThickness(5);
                            
                            
                            
                            rectangle.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            
                            
                            
                            
                            line.setOutlineThickness(5);
                            
                            
                            
                            line.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            
                            
                            
                            
                            eraser.setOutlineThickness(5);
                            
                            
                            
                            eraser.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            
                            
                            
                            
                            curve.setOutlineThickness(5);
                            
                            
                            
                            curve.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            
                            text.setOutlineThickness(5);
                             
                            text.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            pol.setOutlineThickness(5);
                            
                            
                            
                            pol.setOutlineColor(sf::Color(30, 80, 530));
                            
                            
                            
                            
                            
                            
                            
                            break;
                            
                            
                            
                        }
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        if (poly_press == true && tripressed != true && pressed != true && recpressed != true && curve_press != true && event.mouseButton.x > 80)
                            
                            
                            
                        {
                        
                            if (lineclick > 2) {
                                
                                
                                
                                lineclick = 0;
                                
                                
                                
                            }
                            
                            
                            
                            if (lineclick == 0)
                                
                                
                                
                            {
                                
                                
                                
                                line_points[0][0] = event.mouseButton.x;
                                
                                
                                
                                line_points[0][1] = event.mouseButton.y;
                                
                                
                                
                                
                                
                                
                                
                                cout << "rx1--------------" << line_points[0][0] << endl;
                                
                                
                                
                            }
                            
                            
                            
                            // cout << rx1 << " " << ry1 << endl;
                            
                            
                            
                            if (lineclick == 1)
                                
                                
                                
                            {
                                
                                
                                
                                line_points[1][0] = event.mouseButton.x;
                                
                                
                                
                                line_points[1][1] = event.mouseButton.y;
                                
                                
                                
                                //cout << rx2 << " " << ry2 << endl;
                                
                                
                                
                            }
                            
                            lineclick++;
                            
                            
                            
                            if (lineclick == 2)
                                
                                
                                
                            {
                                
                                
                                
                                cout << "================check=================" << endl;
                                
                                
                                
                                li[ll]->set_no_of_points(2);
                                
                                
                                
                                li[ll]->contains(line_points);
                                
                                
                                
                                ll++;
                                
                                
                                
                            }
                           
                        }
                        if (event.mouseButton.x > 30 && event.mouseButton.x <= 80 && event.mouseButton.y > 1110 && event.mouseButton.y <= 1160)
                            
                            
                            
                        {
                            
                            
                            
                            linepressed = false;
                            
                            recpressed = false;
                            
                            tripressed = false;
                            
                            pressed = false;
                            
                            curve_press = false;
                            
                            poly_press = false;
                            
                            text_pressed=true ;
                            
                            yellow.setOutlineThickness(5);
                            
                            
                            
                            yellow.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            blue.setOutlineThickness(5);
                            
                            
                            
                            blue.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            green.setOutlineThickness(5);
                            
                            
                            
                            green.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            
                            
                            
                            
                            red.setOutlineThickness(5);
                            
                            
                            
                            red.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            grey.setOutlineThickness(5);
                            
                            
                            
                            grey.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            
                            
                            
                            
                            magenta.setOutlineThickness(5);
                            
                            
                            
                            magenta.setOutlineColor(sf::Color(255, 255, 255));
                            
                            paintbox.setOutlineThickness(5);
                            
                            
                            
                            paintbox.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            black.setOutlineThickness(5);
                            
                            
                            
                            black.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            circle.setOutlineThickness(5);
                            
                            
                            
                            circle.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            triangle.setOutlineThickness(5);
                            
                            
                            
                            triangle.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            
                            
                            
                            
                            rectangle.setOutlineThickness(5);
                            
                            
                            
                            rectangle.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            
                            
                            
                            
                            line.setOutlineThickness(5);
                            
                            
                            
                            line.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            
                            
                            
                            
                            
                            eraser.setOutlineThickness(5);
                            
                            
                            
                            eraser.setOutlineColor(sf::Color(255, 255, 255));
                            
                            curve.setOutlineThickness(5);
                            
                            curve.setOutlineColor(sf::Color(255, 255, 255));
                            
                            pol.setOutlineThickness(5);
                             
                            pol.setOutlineColor(sf::Color(255, 255, 255));
                            
                            
                            text.setOutlineThickness(5);
                             
                            text.setOutlineColor(sf::Color(30, 80, 530));
                            
                            
                            break;
                            
                        }
                        if(text_pressed==true && event.mouseButton.x>80)
                        {
                            font12.loadFromFile(resourcePath()+"Olympus Mount.ttf");
                            if(!font12.loadFromFile(resourcePath()+"Olympus Mount.ttf"))
                            {
                                cout<<"unable to load file"<<endl;
                            }
                            
                            text11.setFont(font12);
                            text11.setString("welcome to AF paint ");
                        }
                        
                        break;
                        
                }
               
            }
            
            
            if (triclick == 0 && click == 0 && recclick == 0 && lineclick == 0) {
                window.clear(sf::Color::White);
                
                
            }
            
            
            
            
            window.draw(black);
            
            
            
            window.draw(yellow);
            
            
            
            window.draw(blue);
            
            
            
            window.draw(green);
            
            
            
            window.draw(red);
            
            
            
            window.draw(grey);
            
            
            
            window.draw(magenta);
            
            
            
            window.draw(paintbox);
            
            
            
            window.draw(circle);
            
            
            
            window.draw(triangle);
            
            
            
            window.draw(rectangle);
            
            
            
            window.draw(line);
            
            
            
            window.draw(shape1);
            
            
            
            window.draw(eraser);
            
            
            
            window.draw(curve);
            
            
            
            window.draw(pol);
            window.draw(text);
            
            window.draw(text11);
            if (triclick > 3 ) {
                
                
                
                for (int i = 0; i < tt; i++)
                    
                    
                    if (t[i] != nullptr) {
                        t[i]->draw();
                    }
                 
            }
            
            if (click > 2 ) {
                
                for (int i = 0; i < cc; i++) {
                    
                     
                    if (circle_clr[i] == 0) {
                        
                        
                        //c[i]._color=" ";
                        
                        
                        if (c[i] != nullptr) {
                            c[i]->draw();
                           // pressed=false ;
                        }

                    }
                       
                }
                 
            }
           
            if (recclick > 2 ) {
                
               // for (int i = 0; i < rr; i++) {
                    
                    
                    if (r[rr-1] != nullptr) {
                        r[rr-1]->draw();
                    }
                    
                //}
                
            }
            
            if (recclick > 2 ) {
                
                // for (int i = 0; i < rr; i++) {
                
                // r[rr-1]._color="Blue" ;
                
               // recpressed=true ;
                if (r[rr - 1] != nullptr) {
                    r[rr - 1]->fill(2);
                    
                }

            }
            
            if (lineclick > 2 ) {
                
                for (int i = 0; i < ll; i++) {
                    
                    if (li[i] != nullptr) {
                        li[i]->draw();
                    }
           
                }
                
            }
            
            if (curve_click > 2 ) {
                
                
                if (c_curve[0] != nullptr) {
                    c_curve[0]->draw();
                    
                }
                 
            }
            
            
            if (click > 2 )
            {
               // pressed=true ;
                if (circle_clr[cc-1 ] != 0) {
                    
                    
                    if (c[cc-1 ] != nullptr) {
                        c[cc-1]->fill(2);
                      //  pressed=false ;
                    }
                }
                
            }
            // Update the window
            window.display();
        }
        
    }
    else
        
        cout << "INVALID choice!!!" << endl;
    
    return EXIT_SUCCESS;
   
}

